/**
 * @file      mem_map.h
 *
 * @details   Where every byte of audio state lives, and the compile-time proof
 *            that it fits.
 *
 *            ------------------------------------------------------------------
 *            WHY THERE IS NO ALLOCATOR
 *            ------------------------------------------------------------------
 *
 *            Two constraints from the GUI model make dynamic allocation
 *            unnecessary:
 *
 *              1. Chain widths always sum to AUDIO_CH_QTY, so the plane count is
 *                 a compile-time constant in every topology.
 *              2. At most one instance of each effect TYPE exists per chain.
 *
 *            Together these mean memory can be reserved per (plane, effect type)
 *            rather than per instance. Every effect declares one static array
 *            indexed by plane, in its own .c file, using the section macros
 *            below. Nothing is allocated, nothing can fail, nothing can
 *            fragment, and no configuration the GUI permits can ever be
 *            rejected for lack of memory.
 *
 *            The cost is that memory is reserved whether or not an effect is
 *            currently placed in a chain. The budget below shows that this is
 *            affordable with room to spare.
 *
 *            ------------------------------------------------------------------
 *            PHYSICAL MEMORY
 *            ------------------------------------------------------------------
 *
 *            DTCM        128 KiB   0x20000000  zero wait state, never cached
 *            ITCM         64 KiB   0x00000000  zero wait state, code only
 *            AXI SRAM    512 KiB   0x24000000  D1, cacheable
 *            SRAM1/2/3   288 KiB   0x30000000  D2
 *            SRAM4        64 KiB   0x38000000  D3
 *            SDRAM bank1  16 MiB   0xC0000000  W9812G6JH, 16-bit, SDCLK 120 MHz
 *            SDRAM bank2  16 MiB   0xD0000000  W9812G6JH, dedicated to loops
 *
 *            Placement rules:
 *              - Audio scratch and hot state -> DTCM. Zero wait state and never
 *                cached, so no cache maintenance is ever required.
 *              - Short delay lines (reverb, chorus, flanger, vibrato) -> AXI
 *                SRAM. They are touched every block by every plane; in SDRAM
 *                they would thrash the 16 KiB D-cache with zero reuse.
 *              - Long delay lines -> SDRAM bank 1. One stream per plane, 512 B
 *                per block, about 1.5 MB/s total. Negligible against ~150 MB/s.
 *              - Loop audio -> SDRAM bank 2, packed 24-bit.
 *
 *            MPU: map the SDRAM audio regions write-through, no write-allocate.
 *            Delay lines are streamed with no reuse, so write-allocate only
 *            costs a read-for-ownership on data that is never read back.
 *
 * @version   1.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      31.08.2026 - First release
 *
 * @copyright RAT Synthesizers
 */

#ifndef MEM_MAP_H
#define MEM_MAP_H



/***************************************************************************************************
* Module includes
***************************************************************************************************/

#include "general.h"
#include "audio_cfg.h"



/***************************************************************************************************
* Section placement macros
***************************************************************************************************/

#ifdef FXC_HOST_BUILD

/* Host test build: everything is ordinary memory. */
#define IN_DTCM
#define IN_ITCM
#define IN_SRAM_FAST
#define IN_SDRAM_FX
#define IN_SDRAM_LOOP
#define IN_DMA_BUF
#define MEM_ALIGN(n)

#else

/*
 * NOTE ON THE LINKER SCRIPT
 *
 * The existing STM32H743VITX_FLASH.ld declares .dtcm / .itcm / .ramd1 / .ramd2 /
 * .ramd3 as output sections with NO input-section patterns, so objects only land
 * there through GNU ld's orphan-merge-by-name rule. Worse, they are (NOLOAD):
 *
 *   - .dtcm gets neither the .data copy nor the .bss zero fill, so anything
 *     placed there is GARBAGE at reset. In the old C++ project this was hidden
 *     because global constructors ran. In C there are no constructors, so every
 *     IN_DTCM object below MUST be explicitly initialised by its module's Init
 *     function. AudioSys_Init does this.
 *
 *   - .itcm is (NOLOAD) too, so code placed there would never be copied from
 *     flash and would execute garbage. Before using IN_ITCM the section needs
 *     "AT> FLASH" plus a copy loop in Reset_Handler, exactly like .data.
 *
 * See Test/README or the project README for the corrected linker script fragment.
 */
#define IN_DTCM         __attribute__((section(".dtcm"),      used))
#define IN_ITCM         __attribute__((section(".itcm"),      used))
#define IN_SRAM_FAST    __attribute__((section(".ramd1"),     used))
#define IN_SDRAM_FX     __attribute__((section(".sdram_fx"),  used))
#define IN_SDRAM_LOOP   __attribute__((section(".sdram_loop"),used))
#define IN_DMA_BUF      __attribute__((section(".ramd1dma"),  used))
#define MEM_ALIGN(n)    __attribute__((aligned(n)))

#endif /* FXC_HOST_BUILD */

/** Cache line size. Align anything that DMA touches, and anything streamed. */
#define MEM_CACHE_LINE_BYTES        (32U)



/***************************************************************************************************
* Per-plane reservations
***************************************************************************************************/

/** Long delay line, FLOAT32, SDRAM bank 1. */
#define MEM_DELAY_BYTES_PER_PLANE       (DELAY_MAX_FRAMES * 4UL)

/** Modulation delay line, FLOAT32, AXI SRAM. Used by chorus, flanger, vibrato. */
#define MEM_MODDELAY_BYTES_PER_PLANE    (MODDELAY_MAX_FRAMES * 4UL)

/** Reverb delay memory, FLOAT32, AXI SRAM. */
#define MEM_REVERB_BYTES_PER_PLANE      ((U32)REVERB_FRAMES_PER_PLANE * 4UL)

/** Loop audio, packed 24-bit, SDRAM bank 2. */
#define MEM_LOOP_BYTES_PER_PLANE        (LOOP_MAX_BYTES)



/***************************************************************************************************
* Budget
***************************************************************************************************/

#define MEM_SDRAM_BANK_BYTES            (16UL * 1024UL * 1024UL)

/**
 * Budget for short delay lines in internal SRAM.
 *
 * The stock linker script reserves 256 KiB of AXI SRAM for RAM_D1_DMA. The
 * actual DMA need is tiny - 2 KiB of SAI buffers plus the recorder SPI staging
 * buffer - so most of that region should be reclaimed for this budget.
 */
#define MEM_SRAM_FAST_BUDGET_BYTES      (320UL * 1024UL)

/* --- SDRAM bank 1: long delay lines ----------------------------------------------------------- */
#define MEM_SDRAM_FX_TOTAL              (MEM_DELAY_BYTES_PER_PLANE * AUDIO_PLANE_QTY)

/* --- SDRAM bank 2: loop audio ----------------------------------------------------------------- */
#define MEM_SDRAM_LOOP_TOTAL            (MEM_LOOP_BYTES_PER_PLANE * AUDIO_PLANE_QTY)

/* --- Internal SRAM: modulation delays (x3 effects) + reverb ----------------------------------- */
#define MEM_SRAM_FAST_TOTAL             (((MEM_MODDELAY_BYTES_PER_PLANE * 3UL) +                  \
                                          MEM_REVERB_BYTES_PER_PLANE) * AUDIO_PLANE_QTY)

/*
 * Budget at the values in audio_cfg.h (4 planes, 4 s delay, 15 s loop):
 *
 *   SDRAM bank 1   3 072 000 B    2.93 MiB of 16 MiB   -> 13 MiB spare
 *                                                         (enough to raise
 *                                                          DELAY_MAX_SEC to 16)
 *   SDRAM bank 2   8 640 000 B    8.24 MiB of 16 MiB   -> 7.4 MiB spare
 *                                                         (enough for looper
 *                                                          undo at ~12.8 s)
 *   AXI SRAM         232 960 B     228 KiB of 320 KiB
 *   DTCM               ~8 KiB      scratch, meters, parameters
 */

FXC_STATIC_ASSERT(MEM_SDRAM_FX_TOTAL   <= MEM_SDRAM_BANK_BYTES,       mem_sdram_fx_fits);
FXC_STATIC_ASSERT(MEM_SDRAM_LOOP_TOTAL <= MEM_SDRAM_BANK_BYTES,       mem_sdram_loop_fits);
FXC_STATIC_ASSERT(MEM_SRAM_FAST_TOTAL  <= MEM_SRAM_FAST_BUDGET_BYTES, mem_sram_fast_fits);



#endif // #ifndef MEM_MAP_H

/****************************************** end of file *******************************************/
