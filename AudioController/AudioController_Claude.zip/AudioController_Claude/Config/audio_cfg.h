/**
 * @file      audio_cfg.h
 *
 * @details   Audio-controller-only configuration.
 *
 *            Dimensions that the interface controller also needs (channel count,
 *            grid size, parameter count, sample rate, loop length) live in
 *            Shared/fx_defs.h so there is exactly one definition of each. This
 *            file holds what only the audio side cares about: block size,
 *            memory limits and link tuning.
 *
 *            There is no dynamic allocation anywhere in this project. Changing a
 *            value here changes a static array somewhere and nothing else.
 *
 * @version   1.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      31.08.2026 - First release
 *
 * @copyright RAT Synthesizers
 */

#ifndef AUDIO_CFG_H
#define AUDIO_CFG_H



/***************************************************************************************************
* Module includes
***************************************************************************************************/

// Get general definitions
#include "general.h"

// Get the dimensions shared with the interface controller
#include "fx_defs.h"



/***************************************************************************************************
* Definitions of global (public) constants
***************************************************************************************************/

// ------------------------------------------------------------------------------------------------
// Block processing
// ------------------------------------------------------------------------------------------------

// Frames processed per DSP block.
//
// Buffering latency is 2 * AUDIO_BLOCK_FRAMES:
//     32 frames -> 0.67 ms      64 frames -> 1.33 ms      128 frames -> 2.67 ms
// Add codec group delay on top. 64 is the recommended starting point; measure on
// hardware with the DWT load meter before changing it.
//
// Must be a power of two. Valid values: [16 ; 256].
#define AUDIO_BLOCK_FRAMES              (64U)

// Full-scale magnitude of one hardware sample, as a power of two.
// A power of two keeps the scale factor exact in FLOAT32 and makes -1.0f map
// exactly to negative full scale. Do NOT use 8388607.
#define AUDIO_FULLSCALE                 (8388608.0f)    /* 2^23, 24-bit */

// ------------------------------------------------------------------------------------------------
// Effect limits
// ------------------------------------------------------------------------------------------------

// Longest delay line, seconds. Reserved statically per plane in SDRAM bank 1.
// Raising this is cheap: bank 1 holds ~3 MiB of 16 MiB at 4 s. See mem_map.h.
#define DELAY_MAX_SEC                   (4U)

// Longest modulation delay (chorus / flanger / vibrato), milliseconds.
#define MODDELAY_MAX_MS                 (30U)

// Reverb delay-line budget per plane, samples. Sized for a 4-line FDN with the
// longest line at ~50 ms plus 4 diffusion allpasses.
#define REVERB_FRAMES_PER_PLANE         (10240U)

// ------------------------------------------------------------------------------------------------
// Looper storage
// ------------------------------------------------------------------------------------------------

// Loop audio is stored packed 24-bit (3 bytes/sample) in SDRAM bank 2.
//
// Rationale: FLOAT32 would cost 11.5 MiB of 16 MiB and close the door on undo,
// which needs a second buffer of the same size. Packed 24-bit costs 8.6 MiB and
// leaves 7.4 MiB - enough for undo at ~12.8 s - at no audible cost.
#define LOOP_BYTES_PER_SAMPLE           (3U)

// ------------------------------------------------------------------------------------------------
// Control link and telemetry
// ------------------------------------------------------------------------------------------------

// Telemetry frame period, milliseconds. Matched to GUI refresh, not to audio.
#define TELEMETRY_PERIOD_MS             (40U)

// Control link receive ring buffer, bytes. Must be a power of two.
#define CTRL_RX_RING_BYTES              (256U)

// Mixer gain smoothing time constant, milliseconds.
// Without this every gain change zipper-clicks. Do not set to zero.
#define MIX_GAIN_SMOOTH_MS              (20U)

// Peak meter decay, dB per second, reported through telemetry.
#define METER_DECAY_DB_PER_SEC          (20.0f)



/***************************************************************************************************
* Derived constants - do not edit
***************************************************************************************************/

#define AUDIO_BLOCK_PERIOD_US           ((AUDIO_BLOCK_FRAMES * 1000000UL) / AUDIO_SAMPLE_RATE_HZ)

/* No casts in these: they are evaluated by the preprocessor in the #if checks
 * below, where a cast is not a valid token. AUDIO_SAMPLE_RATE_HZ carries the UL
 * suffix, so every product is already unsigned long. */
#define DELAY_MAX_FRAMES                (DELAY_MAX_SEC * AUDIO_SAMPLE_RATE_HZ)
#define MODDELAY_MAX_FRAMES             ((MODDELAY_MAX_MS * AUDIO_SAMPLE_RATE_HZ) / 1000UL)
#define LOOP_MAX_FRAMES                 (LOOP_MAX_SEC * AUDIO_SAMPLE_RATE_HZ)
#define LOOP_MAX_BYTES                  (LOOP_MAX_FRAMES * LOOP_BYTES_PER_SAMPLE)



/***************************************************************************************************
* Configuration sanity checks
***************************************************************************************************/

#if ((AUDIO_BLOCK_FRAMES & (AUDIO_BLOCK_FRAMES - 1U)) != 0U)
#error "AUDIO_BLOCK_FRAMES must be a power of two"
#endif

#if (AUDIO_BLOCK_FRAMES < 16U)
#error "AUDIO_BLOCK_FRAMES below 16 makes per-block overhead dominate"
#endif

#if (AUDIO_PLANE_QTY != AUDIO_CH_QTY)
#error "Plane count must equal physical channel count - see the width invariant in fx_defs.h"
#endif

#if ((CHAIN_MAX_QTY * CHAIN_MAX_WIDTH) < AUDIO_CH_QTY)
#error "Chains cannot cover all physical channels"
#endif

#if ((AUDIO_PLANE_QTY % LOOPER_QTY) != 0U)
#error "Planes must divide evenly between loopers"
#endif

#if ((CTRL_RX_RING_BYTES & (CTRL_RX_RING_BYTES - 1U)) != 0U)
#error "CTRL_RX_RING_BYTES must be a power of two"
#endif

#if (MODDELAY_MAX_FRAMES >= DELAY_MAX_FRAMES)
#error "Modulation delay must be shorter than the main delay line"
#endif



#endif // #ifndef AUDIO_CFG_H

/****************************************** end of file *******************************************/
