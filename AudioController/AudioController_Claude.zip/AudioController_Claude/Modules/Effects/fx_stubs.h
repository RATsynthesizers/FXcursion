/**
 * @file      fx_stubs.h
 *
 * @details   Effects that are registered, reserve their memory and pass audio
 *            through unchanged, but whose DSP is not written yet.
 *
 *            They exist so that the grid, the protocol, the parameter model, the
 *            memory budget and the tests are all complete and exercisable today.
 *            Each one is a self-contained job: replace the body, delete the entry
 *            from this file, add a real fx_<name>.c with both variants.
 *
 *            Both the mono and the stereo variant of each is declared, because
 *            they are separate effect types - see fx_defs.h. The delay memory
 *            they need IS declared in fx_stubs.c, so the linker map shows the
 *            true footprint of the design rather than an optimistic one.
 *
 * @version   2.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      01.09.2026 - 2.0.0 - mono and stereo split
 *
 * @copyright RAT Synthesizers
 */

#ifndef FX_STUBS_H
#define FX_STUBS_H



/***************************************************************************************************
* Module includes
***************************************************************************************************/

#include "fx_common.h"



/***************************************************************************************************
* Declarations of global (public) functions
***************************************************************************************************/

#define FX_STUB_DECLARE(name)                                                                   \
    extern void Fx##name##M_Process(const FX_CTX* pCtx, FLOAT32* const apPlane[], const U16 n); \
    extern void Fx##name##M_Reset(const U8 nPlaneBase, const U8 nWidth);                        \
    extern void Fx##name##S_Process(const FX_CTX* pCtx, FLOAT32* const apPlane[], const U16 n); \
    extern void Fx##name##S_Reset(const U8 nPlaneBase, const U8 nWidth)

FX_STUB_DECLARE(Chorus);
FX_STUB_DECLARE(Flanger);
FX_STUB_DECLARE(Vibrato);
FX_STUB_DECLARE(Reverb);
FX_STUB_DECLARE(Phaser);
FX_STUB_DECLARE(Compressor);
FX_STUB_DECLARE(Distortion);



#endif // #ifndef FX_STUBS_H

/****************************************** end of file *******************************************/
