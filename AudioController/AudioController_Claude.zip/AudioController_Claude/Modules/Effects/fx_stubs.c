/**
 * @file      fx_stubs.c
 *
 * @details   Unimplemented effects: registered, memory reserved, audio passes
 *            through unchanged. Every one is TODO.
 *
 *            Each TODO says what the mono variant is and what the STEREO variant
 *            adds, because that extra parameter is the whole reason the pool is
 *            split by width.
 *
 * @version   2.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      01.09.2026 - 2.0.0 - mono and stereo split
 *
 * @copyright RAT Synthesizers
 */



/***************************************************************************************************
* Module includes
***************************************************************************************************/

#include "fx_stubs.h"

#include "mem_map.h"



/***************************************************************************************************
* Definitions of local (private) variables
***************************************************************************************************/

/*
 * Modulation delay lines, internal SRAM. Shared by each effect's two variants,
 * because a mono and a stereo instance can never be live on the same planes.
 *
 * These are also why mem_map.h has two memory tiers. A fully loaded machine has
 * many short lines being read and written every block; in SDRAM they would
 * replace the entire 16 KiB D-cache several times per block with zero reuse,
 * costing roughly a quarter of the block budget in linefills. In AXI SRAM they
 * cost nothing. Only the long delay lines and the loop buffers belong in SDRAM.
 *
 * 1440 frames each (MODDELAY_MAX_MS at 48 kHz) x 4 planes x 4 B = 23 KiB each.
 */
static FLOAT32 aChorusLine[AUDIO_PLANE_QTY][MODDELAY_MAX_FRAMES]  IN_SRAM_FAST MEM_ALIGN(32);
static FLOAT32 aFlangerLine[AUDIO_PLANE_QTY][MODDELAY_MAX_FRAMES] IN_SRAM_FAST MEM_ALIGN(32);
static FLOAT32 aVibratoLine[AUDIO_PLANE_QTY][MODDELAY_MAX_FRAMES] IN_SRAM_FAST MEM_ALIGN(32);

/*
 * Reverb delay memory, internal SRAM.
 * Sized for a 4-line FDN with the longest line at about 50 ms plus 4 diffusion
 * allpasses: 10240 frames x 4 planes x 4 B = 160 KiB.
 */
static FLOAT32 aReverbMem[AUDIO_PLANE_QTY][REVERB_FRAMES_PER_PLANE] IN_SRAM_FAST MEM_ALIGN(32);



/***************************************************************************************************
* Definitions of local (private) functions
***************************************************************************************************/

static void ClearLines(FLOAT32 (*const pBank)[MODDELAY_MAX_FRAMES],
                       const U8 nPlaneBase,
                       const U8 nWidth)
{
    U8 p;

    for (p = 0U; p < nWidth; p++)
    {
        if ((nPlaneBase + p) < AUDIO_PLANE_QTY)
        {
            U32 i;

            for (i = 0UL; i < MODDELAY_MAX_FRAMES; i++)
            {
                pBank[nPlaneBase + p][i] = 0.0f;
            }
        }
    }
}

//--------------------------------------------------------------------------------------------------

static void ClearReverb(const U8 nPlaneBase, const U8 nWidth)
{
    U8 p;

    for (p = 0U; p < nWidth; p++)
    {
        if ((nPlaneBase + p) < AUDIO_PLANE_QTY)
        {
            U32 i;

            for (i = 0UL; i < (U32)REVERB_FRAMES_PER_PLANE; i++)
            {
                aReverbMem[nPlaneBase + p][i] = 0.0f;
            }
        }
    }
}

//--------------------------------------------------------------------------------------------------

static void PassThrough(const FX_CTX* pCtx, FLOAT32* const apPlane[], const U16 nFrames)
{
    // Deliberately does nothing to the audio. Keeping the arguments referenced
    // stops the compiler warning about them and documents that the signature is
    // the real one.
    (void)pCtx;
    (void)apPlane;
    (void)nFrames;
}

/** Boilerplate for an effect whose two variants share one delay bank. */
#define FX_STUB_LINE_IMPL(name, bank)                                                       \
    void Fx##name##M_Reset(const U8 nPlaneBase, const U8 nWidth)                            \
    { ClearLines(bank, nPlaneBase, nWidth); }                                               \
    void Fx##name##M_Process(const FX_CTX* pCtx, FLOAT32* const apPlane[], const U16 n)     \
    { PassThrough(pCtx, apPlane, n); }                                                      \
    void Fx##name##S_Reset(const U8 nPlaneBase, const U8 nWidth)                            \
    { ClearLines(bank, nPlaneBase, nWidth); }                                               \
    void Fx##name##S_Process(const FX_CTX* pCtx, FLOAT32* const apPlane[], const U16 n)     \
    { PassThrough(pCtx, apPlane, n); }

/** Boilerplate for an effect with no delay memory. */
#define FX_STUB_PLAIN_IMPL(name)                                                            \
    void Fx##name##M_Reset(const U8 nPlaneBase, const U8 nWidth)                            \
    { (void)nPlaneBase; (void)nWidth; }                                                     \
    void Fx##name##M_Process(const FX_CTX* pCtx, FLOAT32* const apPlane[], const U16 n)     \
    { PassThrough(pCtx, apPlane, n); }                                                      \
    void Fx##name##S_Reset(const U8 nPlaneBase, const U8 nWidth)                            \
    { (void)nPlaneBase; (void)nWidth; }                                                     \
    void Fx##name##S_Process(const FX_CTX* pCtx, FLOAT32* const apPlane[], const U16 n)     \
    { PassThrough(pCtx, apPlane, n); }



/***************************************************************************************************
* Definitions of global (public) functions
***************************************************************************************************/

/* ---- Chorus ---------------------------------------------------------------------------------
 * MONO   TODO: LFO-modulated short delay, fractional read via FxUtil_DelayRead,
 *        rate from FxParam_RateHz so it can be tempo-synced.
 *        fx_delay.c shows the tap-precision pattern; fx_tremolo.c shows the LFO.
 * STEREO adds SPREAD - the LFO phase offset between the two planes. At 0 it is a
 *        dual-mono chorus; at 1 the two sides sweep in antiphase, which is what
 *        actually makes a chorus sound wide rather than just doubled.
 */
FX_STUB_LINE_IMPL(Chorus, aChorusLine)

/* ---- Flanger --------------------------------------------------------------------------------
 * MONO   TODO: as chorus but with a shorter delay range and a feedback path.
 * STEREO adds SPREAD, same meaning as chorus.
 */
FX_STUB_LINE_IMPL(Flanger, aFlangerLine)

/* ---- Vibrato --------------------------------------------------------------------------------
 * MONO   TODO: modulated delay with NO dry path - vibrato is 100% wet by definition.
 * STEREO adds SPREAD.
 */
FX_STUB_LINE_IMPL(Vibrato, aVibratoLine)

/* ---- Reverb ---------------------------------------------------------------------------------
 * MONO   TODO: 4-line FDN with a Hadamard mixing matrix, 4 input diffusion
 *        allpasses, one-pole damping in each feedback line, and a pre-delay tap.
 *        Pre-delay is FX_PF_SYNCABLE - resolve it with FxParam_TimeSec.
 *        Set FPSCR.FZ at boot before writing this: reverb tails decay into
 *        denormal range and denormals can cost 10-100x on some operations.
 *
 * STEREO adds WIDTH, and is genuinely a different algorithm rather than the mono
 *        one run twice. ONE tail, decorrelated across the two planes: sum both
 *        inputs into the FDN and take two DIFFERENT output taps out. Two
 *        independent mono reverbs sound like two rooms, not one room in stereo,
 *        and on a guitar that difference is immediately obvious.
 *        Use aReverbMem[nPlaneBase] and aReverbMem[nPlaneBase + 1] as the two
 *        banks of the single instance.
 */
void FxReverbM_Reset(const U8 nPlaneBase, const U8 nWidth) { ClearReverb(nPlaneBase, nWidth); }
void FxReverbM_Process(const FX_CTX* pCtx, FLOAT32* const apPlane[], const U16 n)
{ PassThrough(pCtx, apPlane, n); }
void FxReverbS_Reset(const U8 nPlaneBase, const U8 nWidth) { ClearReverb(nPlaneBase, nWidth); }
void FxReverbS_Process(const FX_CTX* pCtx, FLOAT32* const apPlane[], const U16 n)
{ PassThrough(pCtx, apPlane, n); }

/* ---- Phaser ---------------------------------------------------------------------------------
 * MONO   TODO: cascaded first-order allpass stages with an LFO-swept corner, plus
 *        feedback. Only a handful of floats of state per plane, no delay line.
 *        The Stages parameter is FX_PF_STEPPED - quantise it to 2/4/6/8.
 * STEREO adds SPREAD.
 */
FX_STUB_PLAIN_IMPL(Phaser)

/* ---- Compressor -----------------------------------------------------------------------------
 * MONO   TODO: feed-forward peak compressor, log-domain gain computer, separate
 *        attack and release one-poles. Attack and release are the two parameters
 *        most worth an exponential map - linear ones feel wrong at both ends.
 *
 * STEREO adds LINK, and this one matters. At LINK 1 there is ONE detector fed by
 *        max(|L|, |R|) driving ONE gain applied to both planes. At LINK 0 the two
 *        planes have independent detectors. Anything other than full link makes
 *        the stereo image shift left and right in time with whichever side is
 *        louder - the classic dual-mono compressor fault - so 1.0 is the default.
 */
FX_STUB_PLAIN_IMPL(Compressor)

/* ---- Distortion -----------------------------------------------------------------------------
 * MONO   TODO: harder clipping than overdrive, with a tone stack after the
 *        clipper. Consider 2x oversampling around the waveshaper - hard clipping
 *        at 48 kHz aliases audibly, and there is more than enough CPU headroom.
 * STEREO adds SPREAD, same idea as overdrive: the two sides clip slightly
 *        differently so the result has width instead of being mono in two places.
 */
FX_STUB_PLAIN_IMPL(Distortion)

/****************************************** end of file *******************************************/
