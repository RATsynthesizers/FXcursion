/**
 * @file      fx_delay.h
 *
 * @details   Delay, in two distinct types: mono-only and stereo-only.
 *
 *            They are separate effects, not one effect with a width flag - see
 *            the note at the top of fx_defs.h. Both variants live in fx_delay.c
 *            and share their core and their static memory, because a mono and a
 *            stereo instance can never occupy the same planes.
 *
 * @version   2.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      01.09.2026 - 2.0.0 - mono and stereo split
 *
 * @copyright RAT Synthesizers
 */

#ifndef FX_DELAY_H
#define FX_DELAY_H



/***************************************************************************************************
* Module includes
***************************************************************************************************/

#include "fx_common.h"



/***************************************************************************************************
* Declarations of global (public) functions
***************************************************************************************************/

extern void FxDelayM_Process(const FX_CTX* pCtx, FLOAT32* const apPlane[], const U16 nFrames);
extern void FxDelayM_Reset(const U8 nPlaneBase, const U8 nWidth);

extern void FxDelayS_Process(const FX_CTX* pCtx, FLOAT32* const apPlane[], const U16 nFrames);
extern void FxDelayS_Reset(const U8 nPlaneBase, const U8 nWidth);



#endif // #ifndef FX_DELAY_H

/****************************************** end of file *******************************************/
