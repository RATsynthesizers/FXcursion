/**
 * @file      looper.c
 *
 * @details   Looper implementation. See looper.h for the model.
 *
 * @version   1.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      31.08.2026 - First release
 *
 * @copyright RAT Synthesizers
 */



/***************************************************************************************************
* Module includes
***************************************************************************************************/

#include "looper.h"

#include "mem_map.h"
#include "params.h"
#include "Effects/fx_common.h"



/***************************************************************************************************
* Definitions of local (private) constants
***************************************************************************************************/

/** Planes per looper. 4 planes / 2 loopers. */
#define LOOP_PLANES_PER_LOOPER      (AUDIO_PLANE_QTY / LOOPER_QTY)

#define LOOP_SAMPLE_SCALE           (8388608.0f)    /* 2^23 */
#define LOOP_SAMPLE_MAX             (8388607L)
#define LOOP_SAMPLE_MIN             (-8388608L)



/***************************************************************************************************
* Definitions of local (private) data types
***************************************************************************************************/

/**
 * @brief Per-chain transport.
 */
typedef struct stLOOP_TRANSPORT
{
    U8      eState;             /**< PROTO_TRANSPORT_ACT                         */
    U8      nReserved[3];
    U32     nPos;               /**< playhead, frames                            */

} LOOP_TRANSPORT;

/**
 * @brief Per-pair length.
 */
typedef struct stLOOP_LENGTH
{
    U8      nBars;              /**< 0 = empty                                   */
    U8      nReserved[3];
    U32     nFrames;            /**< 0 = empty                                   */
    FLOAT32 fRecordedBpm;       /**< tempo at capture; re-lock placeholder       */

} LOOP_LENGTH;



/***************************************************************************************************
* Definitions of local (private) variables
***************************************************************************************************/

/*
 * Loop audio, packed 24-bit, SDRAM bank 2. Garbage at reset, which is safe
 * because nFrames starts at 0 and nothing is ever read from an empty loop.
 */
static U8 aLoopBuf[AUDIO_PLANE_QTY][LOOP_MAX_BYTES] IN_SDRAM_LOOP MEM_ALIGN(32);

static LOOP_TRANSPORT aTransport[CHAIN_MAX_QTY] IN_DTCM;
static LOOP_LENGTH    aLength[LOOPER_QTY]       IN_DTCM;



/***************************************************************************************************
* Definitions of local (private) functions
***************************************************************************************************/

static U8 LooperOfPlane(const U8 nPlane)
{
    return (U8)(nPlane / LOOP_PLANES_PER_LOOPER);
}

//--------------------------------------------------------------------------------------------------

static void Pack24(U8* const pDst, const FLOAT32 fValue)
{
    S32 nSample = (S32)(FxUtil_Clamp(fValue, -1.0f, 1.0f) * LOOP_SAMPLE_SCALE);

    if (nSample > LOOP_SAMPLE_MAX)
    {
        nSample = LOOP_SAMPLE_MAX;
    }
    else if (nSample < LOOP_SAMPLE_MIN)
    {
        nSample = LOOP_SAMPLE_MIN;
    }
    else
    {
        do_nothing();
    }

    pDst[0] = (U8)((U32)nSample & 0xFFU);
    pDst[1] = (U8)(((U32)nSample >> 8U) & 0xFFU);
    pDst[2] = (U8)(((U32)nSample >> 16U) & 0xFFU);
}

//--------------------------------------------------------------------------------------------------

static FLOAT32 Unpack24(const U8* const pSrc)
{
    U32 nRaw = (U32)pSrc[0] | ((U32)pSrc[1] << 8U) | ((U32)pSrc[2] << 16U);
    S32 nSample;

    if ((nRaw & 0x00800000UL) != 0UL)
    {
        nRaw |= 0xFF000000UL;               // sign extend from 24 to 32 bits
    }

    nSample = (S32)nRaw;

    return (FLOAT32)nSample * (1.0f / LOOP_SAMPLE_SCALE);
}

//--------------------------------------------------------------------------------------------------

static BOOLEAN PairIsIdle(const GRID* const pGrid, const U8 nLooper)
{
    BOOLEAN bIdle = TRUE;
    U8      nChain;

    for (nChain = 0U; nChain < pGrid->nChainQty; nChain++)
    {
        if (LooperOfPlane(pGrid->aPlaneBase[nChain]) == nLooper)
        {
            if (aTransport[nChain].eState != (U8)TRANSPORT_STOP)
            {
                bIdle = FALSE;
                break;
            }
        }
    }

    return bIdle;
}



/***************************************************************************************************
* Definitions of global (public) functions
***************************************************************************************************/

STD_RESULT Looper_Init(void)
{
    U8 i;

    for (i = 0U; i < CHAIN_MAX_QTY; i++)
    {
        aTransport[i].eState       = (U8)TRANSPORT_STOP;
        aTransport[i].nReserved[0] = 0U;
        aTransport[i].nReserved[1] = 0U;
        aTransport[i].nReserved[2] = 0U;
        aTransport[i].nPos         = 0UL;
    }

    for (i = 0U; i < LOOPER_QTY; i++)
    {
        aLength[i].nBars        = 0U;
        aLength[i].nReserved[0] = 0U;
        aLength[i].nReserved[1] = 0U;
        aLength[i].nReserved[2] = 0U;
        aLength[i].nFrames      = 0UL;      // 0 = empty; the SDRAM garbage is never read
        aLength[i].fRecordedBpm = 0.0f;
    }

    return RESULT_OK;
}

//--------------------------------------------------------------------------------------------------

void Looper_TopologyChanged(void)
{
    U8 i;

    // Stop only. The plane buffers and the lengths are left alone - see the
    // rationale in looper.h.
    for (i = 0U; i < CHAIN_MAX_QTY; i++)
    {
        aTransport[i].eState = (U8)TRANSPORT_STOP;
        aTransport[i].nPos   = 0UL;
    }
}

//--------------------------------------------------------------------------------------------------

void Looper_Apply(const PROTO_CFG* const pCfg, const GRID* const pGrid)
{
    U8 nLooper;

    for (nLooper = 0U; nLooper < LOOPER_QTY; nLooper++)
    {
        const U8 nBars = pCfg->aLoopBars[nLooper];

        // Length is shared by the pair, so it may only change when BOTH of its
        // transports are stopped. Truncating audio playing on the other chain
        // would be worse than refusing.
        if (PairIsIdle(pGrid, nLooper) != FALSE)
        {
            aLength[nLooper].nBars = nBars;

            if (nBars == 0U)
            {
                aLength[nLooper].nFrames = 0UL;
            }
            else
            {
                U32 nFrames = (U32)nBars * Params_BarFrames();

                if (nFrames > LOOP_MAX_FRAMES)
                {
                    nFrames = LOOP_MAX_FRAMES;      // GUI should have bounded this
                }

                aLength[nLooper].nFrames = nFrames;
            }
        }
    }
}

//--------------------------------------------------------------------------------------------------

STD_RESULT Looper_Transport(const U8 nChain, const U8 eAction)
{
    STD_RESULT eResult = RESULT_OK;

    if (nChain >= CHAIN_MAX_QTY)
    {
        eResult = RESULT_INVALID_PARAM_0;
    }
    else
    {
        const U8 nLooper = LooperOfPlane(Grid_Active()->aPlaneBase[nChain]);

        switch (eAction)
        {
            case (U8)TRANSPORT_RECORD:
                if (aLength[nLooper].nFrames == 0UL)
                {
                    eResult = RESULT_NOT_OK;        // no bar count set yet
                }
                else
                {
                    aTransport[nChain].nPos   = 0UL;
                    aLength[nLooper].fRecordedBpm = Params_Tempo()->fBpm;
                    aTransport[nChain].eState = (U8)TRANSPORT_RECORD;
                }
                break;

            case (U8)TRANSPORT_OVERDUB:
            case (U8)TRANSPORT_PLAY:
                if (aLength[nLooper].nFrames == 0UL)
                {
                    eResult = RESULT_NOT_OK;
                }
                else
                {
                    aTransport[nChain].eState = eAction;
                }
                break;

            case (U8)TRANSPORT_STOP:
                aTransport[nChain].eState = (U8)TRANSPORT_STOP;
                break;

            case (U8)TRANSPORT_CLEAR:
                // Only the transport and the length are cleared. The SDRAM
                // buffer is left alone: zeroing 2.16 MiB would stall the
                // super-loop for milliseconds, and nothing reads an empty loop.
                aTransport[nChain].eState = (U8)TRANSPORT_STOP;
                aTransport[nChain].nPos   = 0UL;
                aLength[nLooper].nFrames  = 0UL;
                aLength[nLooper].nBars    = 0U;
                break;

            default:
                eResult = RESULT_INVALID_PARAM_1;
                break;
        }
    }

    return eResult;
}

//--------------------------------------------------------------------------------------------------

void Looper_Process(const GRID* const pGrid,
                    const U8 nChain,
                    FLOAT32* const apChain[],
                    const U16 nFrames)
{
    const U8  nBase   = pGrid->aPlaneBase[nChain];
    const U8  nWidth  = pGrid->aWidth[nChain];
    const U8  nLooper = LooperOfPlane(nBase);
    const U32 nLen    = aLength[nLooper].nFrames;
    const U8  eState  = aTransport[nChain].eState;

    U8  p;
    U16 i;
    U32 nPos = aTransport[nChain].nPos;

    if ((nLen == 0UL) || (eState == (U8)TRANSPORT_STOP))
    {
        return;                                     // passthrough
    }

    // Each plane walks its own copy of the position, then the shared one is
    // advanced once at the end.
    for (p = 0U; p < nWidth; p++)
    {
        FLOAT32* const pBuf   = apChain[p];
        U8* const      pLoop  = aLoopBuf[nBase + p];

        nPos = aTransport[nChain].nPos;

        for (i = 0U; i < nFrames; i++)
        {
            U8* const     pSlot = &pLoop[nPos * LOOP_BYTES_PER_SAMPLE];
            const FLOAT32 fIn   = pBuf[i];

            switch (eState)
            {
                case (U8)TRANSPORT_RECORD:
                    Pack24(pSlot, fIn);
                    // Output stays dry while recording, so the player hears
                    // themselves and not a one-loop-old copy.
                    break;

                case (U8)TRANSPORT_OVERDUB:
                {
                    const FLOAT32 fOld = Unpack24(pSlot);

                    Pack24(pSlot, fOld + fIn);
                    pBuf[i] = fIn + fOld;
                    break;
                }

                case (U8)TRANSPORT_PLAY:
                default:
                    pBuf[i] = fIn + Unpack24(pSlot);
                    break;
            }

            nPos++;
            if (nPos >= nLen)
            {
                nPos = 0UL;
            }
        }
    }

    aTransport[nChain].nPos = nPos;

    // A finished first pass of RECORD becomes PLAY automatically, which is what
    // every hardware looper does. The wrap test is valid because the shortest
    // possible loop is one bar - tens of thousands of frames - and a block is 64.
    if ((eState == (U8)TRANSPORT_RECORD) && (nPos < (U32)nFrames))
    {
        aTransport[nChain].eState = (U8)TRANSPORT_PLAY;
    }
}

//--------------------------------------------------------------------------------------------------

void Looper_GetTelemetry(PROTO_TELEMETRY* const pTelem)
{
    U8 i;

    for (i = 0U; i < LOOPER_QTY; i++)
    {
        pTelem->aLoopLen[i] = aLength[i].nFrames;
        pTelem->aLoopPos[i] = 0UL;
    }

    for (i = 0U; i < CHAIN_MAX_QTY; i++)
    {
        const U8 nLooper = LooperOfPlane(Grid_Active()->aPlaneBase[i]);

        pTelem->aTransport[i] = aTransport[i].eState;

        // Report the playhead of whichever chain in the pair is running, so the
        // GUI loop indicator has something to follow.
        if (aTransport[i].eState != (U8)TRANSPORT_STOP)
        {
            pTelem->aLoopPos[nLooper] = aTransport[i].nPos;
        }
    }
}

/****************************************** end of file *******************************************/
