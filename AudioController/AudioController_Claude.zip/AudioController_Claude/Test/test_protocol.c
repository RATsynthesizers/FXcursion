/**
 * @file      test_protocol.c
 *
 * @details   Wire format, CRC, framing and resynchronisation.
 *
 *            These are the tests that matter most, because a protocol bug does
 *            not crash - it silently rearranges somebody's signal chain.
 *
 * @copyright RAT Synthesizers
 */

#include "test_util.h"

#include "fx_crc.h"
#include "ctrl_link.h"
#include "grid.h"
#include "params.h"


static U8  aCapture[512];
static U16 nCaptured;

static STD_RESULT CaptureTx(const U8* const pData, const U16 nLength)
{
    U16 i;

    for (i = 0U; (i < nLength) && (nCaptured < (U16)sizeof(aCapture)); i++)
    {
        aCapture[nCaptured] = pData[i];
        nCaptured++;
    }

    return RESULT_OK;
}

static void FeedFrame(const U8 eCmd, const U8* const pPayload, const U8 nLength)
{
    U8  aFrame[PROTO_FRAME_MAX];
    U16 nCrc;
    U16 nPos = 0U;
    U16 i;

    aFrame[nPos] = (U8)PROTO_SYNC0; nPos++;
    aFrame[nPos] = (U8)PROTO_SYNC1; nPos++;
    aFrame[nPos] = nLength;         nPos++;
    aFrame[nPos] = eCmd;            nPos++;

    if (nLength > 0U)
    {
        (void)memcpy(&aFrame[nPos], pPayload, (size_t)nLength);
        nPos = (U16)(nPos + nLength);
    }

    nCrc = Crc16_Ccitt(&aFrame[2], (U16)(nLength + 2U), 0xFFFFU);

    aFrame[nPos] = (U8)(nCrc & 0xFFU);          nPos++;
    aFrame[nPos] = (U8)((nCrc >> 8U) & 0xFFU);  nPos++;

    for (i = 0U; i < nPos; i++)
    {
        CtrlLink_RxByte(aFrame[i]);
    }
}


void Test_Protocol(void)
{
    PROTO_CFG   tCfg;
    U32         nOkBefore;

    /* ---- struct sizes are also compile-time asserted; verify at runtime too --- */
    TEST_BEGIN("wire struct sizes");
    CHECK_EQ_U32(sizeof(PROTO_CFG),       96U);
    CHECK_EQ_U32(sizeof(PROTO_SET_PARAM),  8U);
    CHECK_EQ_U32(sizeof(PROTO_SET_TEMPO),  4U);
    CHECK_EQ_U32(sizeof(PROTO_TRANSPORT),  4U);
    CHECK_EQ_U32(sizeof(PROTO_ACK),        8U);
    CHECK_EQ_U32(sizeof(PROTO_TELEMETRY), 48U);
    TEST_END();

    /* ---- CRC-16/CCITT-FALSE against the standard check vector ---------------- */
    TEST_BEGIN("CRC-16/CCITT-FALSE check vector");
    {
        const U8 aCheck[9] = { '1','2','3','4','5','6','7','8','9' };

        CHECK_EQ_U32(Crc16_Ccitt(aCheck, 9U, 0xFFFFU), 0x29B1U);
    }
    TEST_END();

    (void)CtrlLink_Init(CaptureTx);

    /* ---- a good frame is dispatched and acknowledged ------------------------- */
    TEST_BEGIN("SET_CONFIG dispatched and ACKed");
    nCaptured = 0U;
    Test_MakeDefaultCfg(&tCfg, (U8)TOPO_2_STEREO);
    FeedFrame((U8)PROTO_CMD_SET_CONFIG, (const U8*)&tCfg, (U8)sizeof(tCfg));
    CHECK_EQ_U32(CtrlLink_Poll(), 1U);
    CHECK_EQ_U32(Grid_Active()->eTopology, (U8)TOPO_2_STEREO);
    CHECK_EQ_U32(Grid_Active()->nChainQty, 2U);
    /* ACK frame: sync, sync, len, cmd, payload, crc, crc */
    CHECK_EQ_U32(nCaptured, (U16)(sizeof(PROTO_ACK) + PROTO_OVERHEAD_BYTES));
    CHECK_EQ_U32(aCapture[3], (U8)PROTO_CMD_ACK);
    CHECK_EQ_U32(aCapture[4], (U8)PROTO_RES_OK);
    TEST_END();

    /* ---- a corrupted frame is rejected, and the NEXT one still parses -------- */
    TEST_BEGIN("bad CRC rejected, link resynchronises");
    nOkBefore = CtrlLink_Stats()->nFramesOk;
    Test_MakeDefaultCfg(&tCfg, (U8)TOPO_4_MONO);
    tCfg.nBpmX10 = 1000U;
    FeedFrame((U8)PROTO_CMD_SET_CONFIG, (const U8*)&tCfg, (U8)sizeof(tCfg));
    CtrlLink_RxByte(0xFFU);                     /* trailing garbage */
    (void)CtrlLink_Poll();
    CHECK_EQ_U32(CtrlLink_Stats()->nFramesOk, nOkBefore + 1U);

    /* now a genuinely damaged frame */
    {
        U8 aBad[PROTO_FRAME_MAX];
        U16 i;

        aBad[0] = (U8)PROTO_SYNC0;
        aBad[1] = (U8)PROTO_SYNC1;
        aBad[2] = (U8)sizeof(PROTO_SET_TEMPO);
        aBad[3] = (U8)PROTO_CMD_SET_TEMPO;
        aBad[4] = 0x00U; aBad[5] = 0x00U; aBad[6] = 0x00U; aBad[7] = 0x00U;
        aBad[8] = 0x00U; aBad[9] = 0x00U;       /* deliberately wrong CRC */

        nOkBefore = CtrlLink_Stats()->nCrcErrors;
        for (i = 0U; i < 10U; i++)
        {
            CtrlLink_RxByte(aBad[i]);
        }
        (void)CtrlLink_Poll();
        CHECK_EQ_U32(CtrlLink_Stats()->nCrcErrors, nOkBefore + 1U);
    }

    /* and the link is still usable afterwards */
    nOkBefore = CtrlLink_Stats()->nFramesOk;
    FeedFrame((U8)PROTO_CMD_PING, NULL_PTR, 0U);
    (void)CtrlLink_Poll();
    CHECK_EQ_U32(CtrlLink_Stats()->nFramesOk, nOkBefore + 1U);
    TEST_END();

    /* ---- structurally impossible grids are refused --------------------------- */
    TEST_BEGIN("invalid grids refused, old graph survives");
    {
        const U8 eBefore = Grid_Active()->eTopology;
        PROTO_ACK tAck;

        /* two FX blocks in one chain */
        Test_MakeDefaultCfg(&tCfg, (U8)TOPO_4_MONO);
        tCfg.aSlot[0][0] = (U8)BLOCK_FX;
        tCfg.aSlot[0][1] = (U8)BLOCK_FX;
        CHECK(Grid_Apply(&tCfg, &tAck) != RESULT_OK);
        CHECK_EQ_U32(tAck.eResult, (U8)PROTO_RES_BAD_GRID);

        /* mixer that does not span the whole column */
        Test_MakeDefaultCfg(&tCfg, (U8)TOPO_4_MONO);
        tCfg.nMixerCol   = 2;
        tCfg.aSlot[0][2] = (U8)BLOCK_MIXER;
        /* chains 1..3 left empty in that column */
        CHECK(Grid_Apply(&tCfg, &tAck) != RESULT_OK);

        /* the same effect twice inside one FX block */
        Test_MakeDefaultCfg(&tCfg, (U8)TOPO_4_MONO);
        tCfg.aSlot[0][0]   = (U8)BLOCK_FX;
        tCfg.aFxSlot[0][0] = (U8)FX_DELAY_M;
        tCfg.aFxSlot[0][1] = (U8)FX_DELAY_M;
        CHECK(Grid_Apply(&tCfg, &tAck) != RESULT_OK);

        /* bad version */
        Test_MakeDefaultCfg(&tCfg, (U8)TOPO_4_MONO);
        tCfg.nVersion = 99U;
        CHECK(Grid_Apply(&tCfg, &tAck) != RESULT_OK);
        CHECK_EQ_U32(tAck.eResult, (U8)PROTO_RES_BAD_VERSION);

        /* through all of that, the running graph never changed */
        CHECK_EQ_U32(Grid_Active()->eTopology, eBefore);
    }
    TEST_END();

    /* ---- recorder slots never conflict, in any topology ---------------------- */
    TEST_BEGIN("recorder slots never conflict");
    {
        U8 eTopo;

        for (eTopo = 0U; eTopo < (U8)TOPO_QTY; eTopo++)
        {
            PROTO_ACK tAck;
            U8        nChain;
            U8        aUsed[REC_SLOT_QTY];
            U8        i;

            Test_MakeDefaultCfg(&tCfg, eTopo);

            /* a recorder in EVERY chain - the worst case */
            for (nChain = 0U; nChain < CHAIN_MAX_QTY; nChain++)
            {
                tCfg.aSlot[nChain][0] = (U8)BLOCK_RECORDER;
            }

            CHECK(Grid_Apply(&tCfg, &tAck) == RESULT_OK);

            /* exactly REC_SLOT_QTY slots used, none twice */
            CHECK_EQ_U32(tAck.nRecSlotQty, (U8)REC_SLOT_QTY);
            CHECK_EQ_U32(tAck.nStreamWidth, (U8)REC_SLOT_QTY);

            for (i = 0U; i < REC_SLOT_QTY; i++)
            {
                aUsed[i] = 0U;
            }
            for (nChain = 0U; nChain < Grid_Active()->nChainQty; nChain++)
            {
                const U8 nBase = tAck.aRecSlot[nChain];

                CHECK(nBase != (U8)REC_SLOT_NONE);
                for (i = 0U; i < Grid_Active()->aWidth[nChain]; i++)
                {
                    CHECK(nBase + i < (U8)REC_SLOT_QTY);
                    aUsed[nBase + i]++;
                }
            }
            for (i = 0U; i < REC_SLOT_QTY; i++)
            {
                CHECK_EQ_U32(aUsed[i], 1U);
            }
        }
    }
    TEST_END();

    /* ---- preset blob round trip --------------------------------------------- */
    TEST_BEGIN("preset round trip");
    {
        static U8 aBlob[8192];
        PROTO_CFG tOut;
        U32       nWritten = 0UL;

        Test_MakeDefaultCfg(&tCfg, (U8)TOPO_ST1_2MONO);
        tCfg.nBpmX10       = 1435U;
        tCfg.aSlot[0][1]   = (U8)BLOCK_FX;
        tCfg.aFxSlot[0][0] = (U8)FX_OVERDRIVE_M;

        CHECK(Params_PresetSize() <= sizeof(aBlob));
        CHECK(Params_PresetWrite(aBlob, (U32)sizeof(aBlob), &tCfg, &nWritten) == RESULT_OK);
        CHECK_EQ_U32(nWritten, Params_PresetSize());

        CHECK(Params_PresetRead(aBlob, nWritten, &tOut) == RESULT_OK);
        CHECK_EQ_U32(tOut.nBpmX10, 1435U);
        CHECK_EQ_U32(tOut.eTopology, (U8)TOPO_ST1_2MONO);
        CHECK_EQ_U32(tOut.aFxSlot[0][0], (U8)FX_OVERDRIVE_M);

        /* a single flipped bit must be caught */
        aBlob[40] ^= 0x01U;
        CHECK(Params_PresetRead(aBlob, nWritten, &tOut) != RESULT_OK);
    }
    TEST_END();
}
