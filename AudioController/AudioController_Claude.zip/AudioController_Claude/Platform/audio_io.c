/**
 * @file      audio_io.c
 *
 * @details   SAI binding. The only HAL-aware file in the project.
 *
 *            ==================================================================
 *            ONE TIMEBASE
 *            ==================================================================
 *
 *            The existing sai.c already configures all four blocks as slaves
 *            synchronous to SAI1 block A:
 *
 *                hsai_BlockA1  MODESLAVE_RX,  ASYNCHRONOUS, SYNCEXT_OUTBLOCKA
 *                hsai_BlockB1  MODESLAVE_TX,  SYNCHRONOUS
 *                hsai_BlockA2  MODESLAVE_RX,  SYNCHRONOUS_EXT_SAI1
 *                hsai_BlockB2  MODESLAVE_TX,  SYNCHRONOUS_EXT_SAI1
 *
 *            So all four channels share one frame sync and are sample-aligned in
 *            hardware. Exactly ONE interrupt therefore drives the whole machine:
 *            SAI1 block A's DMA. SAI2's callbacks are deliberately left unused.
 *
 *            This is what makes the old bug structurally impossible:
 *
 *                if (saiAdapterCheckUpdate(a1) || saiAdapterCheckUpdate(a2))
 *
 *            short-circuited, so whenever adapter 1 had a flag, adapter 2's
 *            buffer offset never advanced and its flag was never cleared - while
 *            the body went on to read and write adapter 2 through the stale
 *            offset. With one timebase there is nothing to get out of step.
 *
 *            ==================================================================
 *            REQUIRED PLATFORM SETUP - do not skip these
 *            ==================================================================
 *
 *            1. FPSCR.FZ (flush to zero). Reverb and delay tails decay into
 *               denormal range, and denormals can cost 10-100x on some
 *               operations - producing a CPU spike that only happens when the
 *               room goes quiet. One line at boot:
 *                   __set_FPSCR(__get_FPSCR() | (1UL << 24));
 *
 *            2. NVIC PRIORITY. The audio DMA interrupt must be the highest
 *               priority in the system. There is no RTOS here, but if one is
 *               ever added this interrupt must sit numerically ABOVE
 *               configMAX_SYSCALL_INTERRUPT_PRIORITY and must then never call a
 *               FreeRTOS API - not even the FromISR variants.
 *
 *            3. MPU. RAM_D1_DMA (0x24000000) stays non-cacheable for the DMA
 *               buffers. Map the two SDRAM banks write-through, no
 *               write-allocate: delay lines are streamed with no reuse, so
 *               write-allocate only buys a read-for-ownership on data that is
 *               never read back.
 *
 *            4. LINKER SCRIPT. .dtcm and .itcm are (NOLOAD) with no input
 *               patterns in the stock STM32H743VITX_FLASH.ld. .dtcm therefore
 *               gets neither the .data copy nor the .bss zero fill, which is why
 *               AudioSys_Init() explicitly initialises everything. Before using
 *               IN_ITCM at all, the section needs "AT> FLASH" plus a copy loop in
 *               Reset_Handler. See the README.
 *
 *            5. SDRAM. Both banks must be initialised and their refresh started
 *               before AudioSys_Init(), because FxDelay_Reset writes to bank 1.
 *
 * @version   1.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      31.08.2026 - First release
 *
 * @copyright RAT Synthesizers
 */



/***************************************************************************************************
* Module includes
***************************************************************************************************/

#include "audio_io.h"

#ifndef FXC_HOST_BUILD

#include "mem_map.h"
#include "audio_sys.h"
#include "recorder.h"

#include "main.h"
#include "sai.h"
#include "spi.h"



/***************************************************************************************************
* Definitions of local (private) constants
***************************************************************************************************/

/** Frames per DMA half-buffer. */
#define IO_HALF_FRAMES              (AUDIO_BLOCK_FRAMES)

/** Samples in one whole ping-pong buffer, per stereo SAI block. */
#define IO_SAI_BUF_SAMPLES          (IO_HALF_FRAMES * 2U * 2U)   /* 2 ch, 2 halves */

/** Core clock, for the load meter. */
#define IO_CORE_CLOCK_HZ            (480000000UL)

#define IO_BLOCK_BUDGET_CYCLES      ((IO_CORE_CLOCK_HZ / AUDIO_SAMPLE_RATE_HZ) * AUDIO_BLOCK_FRAMES)



/***************************************************************************************************
* Definitions of local (private) variables
***************************************************************************************************/

/*
 * SAI ping-pong buffers. RAM_D1_DMA, which the MPU maps non-cacheable, so no
 * cache maintenance is needed around them.
 *
 * 24-bit audio sits left-aligned in 32-bit slots, so the DMA moves words.
 */
static S32 aRx1[IO_SAI_BUF_SAMPLES] IN_DMA_BUF MEM_ALIGN(32);   /* channels 0,1 */
static S32 aRx2[IO_SAI_BUF_SAMPLES] IN_DMA_BUF MEM_ALIGN(32);   /* channels 2,3 */
static S32 aTx1[IO_SAI_BUF_SAMPLES] IN_DMA_BUF MEM_ALIGN(32);
static S32 aTx2[IO_SAI_BUF_SAMPLES] IN_DMA_BUF MEM_ALIGN(32);

/* Recorder stream, copied out of DTCM because DMA1/DMA2 cannot reach DTCM. */
static S32 aRecTx[AUDIO_BLOCK_FRAMES * REC_SLOT_QTY] IN_DMA_BUF MEM_ALIGN(32);

/*
 * Merged 4-channel interleaved working buffers.
 *
 * The two SAIs deliver two separate stereo streams, so they are merged here.
 * On hardware this is the natural job for MDMA - the interface controller
 * already does exactly this kind of strided gather in Recorder.c - but a plain
 * copy of 256 samples is only a few microseconds of a 1333 us budget, so it is
 * written in C first and left as an optimisation.
 */
static S32 aIn[AUDIO_BLOCK_FRAMES * AUDIO_CH_QTY]  IN_DTCM;
static S32 aOut[AUDIO_BLOCK_FRAMES * AUDIO_CH_QTY] IN_DTCM;

static volatile BOOLEAN bBusy IN_DTCM;



/***************************************************************************************************
* Definitions of global (public) functions
***************************************************************************************************/

STD_RESULT AudioIo_Start(void)
{
    U16 i;

    for (i = 0U; i < IO_SAI_BUF_SAMPLES; i++)
    {
        aRx1[i] = 0L;
        aRx2[i] = 0L;
        aTx1[i] = 0L;
        aTx2[i] = 0L;
    }

    bBusy = FALSE;

    // Enable the DWT cycle counter for the load meter. Without this there is no
    // way to know how close to the deadline the machine is running.
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT       = 0UL;
    DWT->CTRL        |= DWT_CTRL_CYCCNTENA_Msk;

    // Receivers before transmitters, SAI1 block A LAST: it is the master of the
    // synchronisation chain, so everything else must already be armed when its
    // frame sync starts running.
    (void)HAL_SAI_Receive_DMA(&hsai_BlockA2, (U8*)aRx2, IO_SAI_BUF_SAMPLES);
    (void)HAL_SAI_Transmit_DMA(&hsai_BlockB2, (U8*)aTx2, IO_SAI_BUF_SAMPLES);
    (void)HAL_SAI_Transmit_DMA(&hsai_BlockB1, (U8*)aTx1, IO_SAI_BUF_SAMPLES);
    (void)HAL_SAI_Receive_DMA(&hsai_BlockA1, (U8*)aRx1, IO_SAI_BUF_SAMPLES);

    return RESULT_OK;
}

//--------------------------------------------------------------------------------------------------

void AudioIo_OnDmaHalf(const BOOLEAN bSecondHalf)
{
    const U16 nOffset = (bSecondHalf != FALSE) ? (U16)(IO_HALF_FRAMES * 2U) : 0U;
    const U32 nStart  = DWT->CYCCNT;

    U16 i;
    U16 nRecFrames;
    const S32* pRec;

    // Overrun detection: the previous block had not finished when this interrupt
    // arrived. This is the only reliable glitch detector in the system.
    if (bBusy != FALSE)
    {
        AudioSys_NotifyOverrun();
        return;
    }
    bBusy = TRUE;

    /* Merge the two stereo streams into one 4-channel interleaved block. */
    for (i = 0U; i < IO_HALF_FRAMES; i++)
    {
        aIn[((U32)i * AUDIO_CH_QTY) + 0U] = aRx1[nOffset + ((U16)i * 2U) + 0U];
        aIn[((U32)i * AUDIO_CH_QTY) + 1U] = aRx1[nOffset + ((U16)i * 2U) + 1U];
        aIn[((U32)i * AUDIO_CH_QTY) + 2U] = aRx2[nOffset + ((U16)i * 2U) + 0U];
        aIn[((U32)i * AUDIO_CH_QTY) + 3U] = aRx2[nOffset + ((U16)i * 2U) + 1U];
    }

    AudioSys_ProcessBlock(aIn, aOut, IO_HALF_FRAMES);

    /* Split back out to the two transmit streams. */
    for (i = 0U; i < IO_HALF_FRAMES; i++)
    {
        aTx1[nOffset + ((U16)i * 2U) + 0U] = aOut[((U32)i * AUDIO_CH_QTY) + 0U];
        aTx1[nOffset + ((U16)i * 2U) + 1U] = aOut[((U32)i * AUDIO_CH_QTY) + 1U];
        aTx2[nOffset + ((U16)i * 2U) + 0U] = aOut[((U32)i * AUDIO_CH_QTY) + 2U];
        aTx2[nOffset + ((U16)i * 2U) + 1U] = aOut[((U32)i * AUDIO_CH_QTY) + 3U];
    }

    /* Recorder stream out to the interface controller.
     *
     * Copied out of DTCM first: DMA1 and DMA2 cannot address DTCM on the H7.
     * The stream is always REC_SLOT_QTY channels wide with silence in unused
     * slots, so the interface never has to reprogram its de-interleave
     * descriptor when the number of taps changes. */
    pRec = Recorder_GetStream(&nRecFrames);

    for (i = 0U; i < (U16)(nRecFrames * REC_SLOT_QTY); i++)
    {
        aRecTx[i] = pRec[i];
    }

    (void)HAL_SPI_Transmit_DMA(&hspi2, (U8*)aRecTx,
                               (U16)(nRecFrames * REC_SLOT_QTY));

    AudioSys_ReportLoad(DWT->CYCCNT - nStart, IO_BLOCK_BUDGET_CYCLES);

    bBusy = FALSE;
}



/***************************************************************************************************
* SAI callbacks
*
* ONLY SAI1 block A drives the engine. The other three blocks are synchronous to
* it, so their callbacks would fire on the same frame and must not do any work.
***************************************************************************************************/

void HAL_SAI_RxHalfCpltCallback(SAI_HandleTypeDef* hsai)
{
    if (hsai == &hsai_BlockA1)
    {
        AudioIo_OnDmaHalf(FALSE);
    }
}

void HAL_SAI_RxCpltCallback(SAI_HandleTypeDef* hsai)
{
    if (hsai == &hsai_BlockA1)
    {
        AudioIo_OnDmaHalf(TRUE);
    }
}

#endif /* FXC_HOST_BUILD */

/****************************************** end of file *******************************************/
