/**
 * @file      audio_io.h
 *
 * @details   SAI binding: one timebase, four channels, 24-bit.
 *
 *            This is the only file in the project that talks to the HAL, and it
 *            is excluded from the host test build.
 *
 * @version   1.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      31.08.2026 - First release
 *
 * @copyright RAT Synthesizers
 */

#ifndef AUDIO_IO_H
#define AUDIO_IO_H



/***************************************************************************************************
* Module includes
***************************************************************************************************/

#include "general.h"
#include "audio_cfg.h"



/***************************************************************************************************
* Declarations of global (public) functions
***************************************************************************************************/

/**
 * @brief Start the SAI DMA streams and the audio timebase.
 *
 * AudioSys_Init() must already have run.
 */
extern STD_RESULT AudioIo_Start(void);

/**
 * @brief Run one block. Called from the SAI1_A DMA callbacks.
 *
 * @param bSecondHalf  FALSE for the half-complete interrupt, TRUE for complete
 */
extern void AudioIo_OnDmaHalf(const BOOLEAN bSecondHalf);



#endif // #ifndef AUDIO_IO_H

/****************************************** end of file *******************************************/
