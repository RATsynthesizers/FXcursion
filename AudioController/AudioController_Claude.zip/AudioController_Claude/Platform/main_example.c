/**
 * @file      main_example.c
 *
 * @details   What main() looks like. Not part of the build - copy the two USER
 *            sections into the CubeIDE-generated main.c.
 *
 *            The whole program is an ISR and a super-loop. There is no RTOS, no
 *            lock, and no polling of the audio path.
 *
 * @version   1.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      31.08.2026 - First release
 *
 * @copyright RAT Synthesizers
 */

#if 0   /* reference only */

#include "main.h"
#include "usart.h"

#include "audio_cfg.h"
#include "audio_sys.h"
#include "audio_io.h"
#include "ctrl_link.h"


static STD_RESULT UartTx(const U8* const pData, const U16 nLength)
{
    // Non-blocking. If the previous frame is still going out, drop this one -
    // telemetry is periodic and an ACK will be re-requested. NEVER spin here:
    // this runs in the super-loop and the old design's "while (!updateFlag);"
    // on the GUI side is exactly the failure mode to avoid.
    return (HAL_UART_Transmit_DMA(&huart2, (uint8_t*)pData, nLength) == HAL_OK)
           ? RESULT_OK : RESULT_BUSY;
}


int main(void)
{
    U32 nLastTelemetryMs;

    MPU_Config();
    SCB_EnableICache();
    SCB_EnableDCache();

    HAL_Init();
    SystemClock_Config();
    PeriphCommonClock_Config();

    /* ---------------------------------------------------------------------------
     * Flush-to-zero, BEFORE any audio runs.
     *
     * Reverb and delay tails decay into denormal range and denormals can cost
     * 10-100x on some operations - producing a CPU spike that only appears when
     * the room goes quiet, which is a miserable thing to debug.
     * ------------------------------------------------------------------------- */
    __set_FPSCR(__get_FPSCR() | (1UL << 24));

    MX_GPIO_Init();
    MX_DMA_Init();
    MX_FMC_Init();          /* both SDRAM banks, refresh running */
    MX_SAI1_Init();
    MX_SAI2_Init();
    MX_I2C4_Init();
    MX_USART2_UART_Init();
    MX_SPI2_Init();

    CodecPowerUp(CODEC_ADDRESS_0);
    CodecPowerUp(CODEC_ADDRESS_1);

    /* ---------------------------------------------------------------------------
     * AudioSys_Init BEFORE AudioIo_Start.
     *
     * It clears every delay line, which for four 4-second lines is about 3 MiB
     * of SDRAM - milliseconds of work that must not overlap with live audio.
     * It also exists because C has no constructors and .dtcm is NOLOAD: without
     * it every static in this project is whatever the RAM powered up as.
     * ------------------------------------------------------------------------- */
    (void)AudioSys_Init();
    (void)CtrlLink_Init(UartTx);
    (void)AudioIo_Start();

    nLastTelemetryMs = HAL_GetTick();

    while (1)
    {
        /* Parse and dispatch whatever arrived on the control link. Graph
         * rebuilds happen HERE, never in the ISR. */
        (void)CtrlLink_Poll();

        if ((HAL_GetTick() - nLastTelemetryMs) >= TELEMETRY_PERIOD_MS)
        {
            nLastTelemetryMs = HAL_GetTick();
            (void)CtrlLink_SendTelemetry();
        }

        /* Sleep until the next interrupt.
         *
         * The audio runs in the SAI DMA ISR, so the super-loop has nothing to do
         * between commands. The old design spun at 100% duty forever; on a
         * battery-powered pedal this one line is worth real playing time. */
        __WFI();
    }
}


/* UART2 receive: feed the framer one byte at a time. Use circular DMA plus the
 * IDLE line interrupt, or plain interrupt-per-byte at 115200 - either is fine,
 * because nothing here parses. Note what is NOT happening: no command is ever
 * decoded in an ISR, and no receive buffer is ever written to by the CPU while
 * the DMA owns it. */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef* huart)
{
    if (huart == &huart2)
    {
        CtrlLink_RxByte(nRxByte);
        (void)HAL_UART_Receive_IT(&huart2, &nRxByte, 1U);
    }
}

#endif /* reference only */

/****************************************** end of file *******************************************/
