/**
 * @file      ctrl_link.c
 *
 * @details   Control link framer, parser and dispatcher.
 *
 * @version   1.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      31.08.2026 - First release
 *
 * @copyright RAT Synthesizers
 */



/***************************************************************************************************
* Module includes
***************************************************************************************************/

#include "ctrl_link.h"

#include "mem_map.h"
#include "fx_crc.h"
#include "grid.h"
#include "params.h"
#include "looper.h"
#include "audio_sys.h"



/***************************************************************************************************
* Definitions of local (private) data types
***************************************************************************************************/

typedef enum enRX_STATE
{
    RX_SYNC0 = 0,
    RX_SYNC1,
    RX_LEN,
    RX_CMD,
    RX_PAYLOAD,
    RX_CRC_LO,
    RX_CRC_HI

} RX_STATE;



/***************************************************************************************************
* Definitions of local (private) variables
***************************************************************************************************/

/* Lock-free single-producer (ISR) single-consumer (super-loop) ring. */
static volatile U8  aRxRing[CTRL_RX_RING_BYTES] IN_DTCM;
static volatile U16 nRxHead IN_DTCM;
static volatile U16 nRxTail IN_DTCM;

static U8       aPayload[PROTO_PAYLOAD_MAX] IN_DTCM;
static U8       aTxFrame[PROTO_FRAME_MAX]   IN_DTCM;

static RX_STATE eRxState IN_DTCM;
static U8       nRxLen   IN_DTCM;
static U8       nRxCmd   IN_DTCM;
static U8       nRxIdx   IN_DTCM;
static U16      nRxCrc   IN_DTCM;

static CTRL_TX_FN pfTransmit IN_DTCM;
static CTRL_STATS tStats     IN_DTCM;



/***************************************************************************************************
* Definitions of local (private) functions
***************************************************************************************************/

static void Resync(void)
{
    eRxState = RX_SYNC0;
    tStats.nResyncs++;
}

//--------------------------------------------------------------------------------------------------

static void Dispatch(const U8 eCmd, const U8* const pPayload, const U8 nLength)
{
    PROTO_ACK tAck;

    switch (eCmd)
    {
        case (U8)PROTO_CMD_SET_CONFIG:
            if (nLength == (U8)sizeof(PROTO_CFG))
            {
                PROTO_CFG tCfg;

                // Copy out of the parse buffer before use: the payload buffer is
                // reused by the next frame, and unlike the old design nothing
                // ever writes back into a live DMA buffer.
                (void)memcpy(&tCfg, pPayload, sizeof(tCfg));

                (void)Params_SetTempo(tCfg.nBpmX10, tCfg.nBeatsPerBar, tCfg.nBeatUnit);
                (void)Grid_Apply(&tCfg, &tAck);

                // The interface MUST wait for this ACK before trusting the SPI
                // stream layout. See the handshake note in fx_protocol.h.
                (void)CtrlLink_SendFrame((U8)PROTO_CMD_ACK, (const U8*)&tAck, (U8)sizeof(tAck));
            }
            break;

        case (U8)PROTO_CMD_SET_PARAM:
            if (nLength == (U8)sizeof(PROTO_SET_PARAM))
            {
                PROTO_SET_PARAM tCmd;

                (void)memcpy(&tCmd, pPayload, sizeof(tCmd));
                (void)Params_Set(&tCmd);
            }
            break;

        case (U8)PROTO_CMD_SET_TEMPO:
            if (nLength == (U8)sizeof(PROTO_SET_TEMPO))
            {
                PROTO_SET_TEMPO tCmd;

                (void)memcpy(&tCmd, pPayload, sizeof(tCmd));
                (void)Params_SetTempo(tCmd.nBpmX10, tCmd.nBeatsPerBar, tCmd.nBeatUnit);
            }
            break;

        case (U8)PROTO_CMD_TRANSPORT:
            if (nLength == (U8)sizeof(PROTO_TRANSPORT))
            {
                PROTO_TRANSPORT tCmd;

                (void)memcpy(&tCmd, pPayload, sizeof(tCmd));
                (void)Looper_Transport(tCmd.nChain, tCmd.eAction);
            }
            break;

        case (U8)PROTO_CMD_PING:
            (void)CtrlLink_SendFrame((U8)PROTO_CMD_PONG, NULL_PTR, 0U);
            break;

        default:
            // Unknown command from a newer interface build. Ignore it rather
            // than resynchronising: the frame was well formed and CRC-clean.
            do_nothing();
            break;
    }
}

//--------------------------------------------------------------------------------------------------

static void ParseByte(const U8 nByte)
{
    switch (eRxState)
    {
        case RX_SYNC0:
            if (nByte == (U8)PROTO_SYNC0)
            {
                eRxState = RX_SYNC1;
            }
            break;

        case RX_SYNC1:
            if (nByte == (U8)PROTO_SYNC1)
            {
                eRxState = RX_LEN;
            }
            else if (nByte == (U8)PROTO_SYNC0)
            {
                do_nothing();               // stay here: 0xA5 0xA5 0x5A is valid
            }
            else
            {
                eRxState = RX_SYNC0;
            }
            break;

        case RX_LEN:
            if (nByte > (U8)PROTO_PAYLOAD_MAX)
            {
                Resync();
            }
            else
            {
                nRxLen   = nByte;
                nRxIdx   = 0U;
                nRxCrc   = Crc16_Ccitt(&nByte, 1U, 0xFFFFU);
                eRxState = RX_CMD;
            }
            break;

        case RX_CMD:
            nRxCmd   = nByte;
            nRxCrc   = Crc16_Ccitt(&nByte, 1U, nRxCrc);
            eRxState = (nRxLen == 0U) ? RX_CRC_LO : RX_PAYLOAD;
            break;

        case RX_PAYLOAD:
            aPayload[nRxIdx] = nByte;
            nRxCrc           = Crc16_Ccitt(&nByte, 1U, nRxCrc);
            nRxIdx++;

            if (nRxIdx >= nRxLen)
            {
                eRxState = RX_CRC_LO;
            }
            break;

        case RX_CRC_LO:
            nRxIdx   = nByte;               // reuse as CRC low byte
            eRxState = RX_CRC_HI;
            break;

        case RX_CRC_HI:
        default:
        {
            const U16 nGot = (U16)((U16)nRxIdx | ((U16)nByte << 8U));

            if (nGot == nRxCrc)
            {
                tStats.nFramesOk++;
                Dispatch(nRxCmd, aPayload, nRxLen);
            }
            else
            {
                tStats.nCrcErrors++;
            }

            eRxState = RX_SYNC0;
            break;
        }
    }
}



/***************************************************************************************************
* Definitions of global (public) functions
***************************************************************************************************/

STD_RESULT CtrlLink_Init(const CTRL_TX_FN pfTx)
{
    pfTransmit = pfTx;

    nRxHead  = 0U;
    nRxTail  = 0U;
    eRxState = RX_SYNC0;
    nRxLen   = 0U;
    nRxCmd   = 0U;
    nRxIdx   = 0U;
    nRxCrc   = 0U;

    tStats.nFramesOk    = 0UL;
    tStats.nCrcErrors   = 0UL;
    tStats.nResyncs     = 0UL;
    tStats.nRxOverflows = 0UL;

    return RESULT_OK;
}

//--------------------------------------------------------------------------------------------------

void CtrlLink_RxByte(const U8 nByte)
{
    const U16 nNext = (U16)((nRxHead + 1U) & (CTRL_RX_RING_BYTES - 1U));

    if (nNext == nRxTail)
    {
        tStats.nRxOverflows++;              // drop; the CRC will catch the damage
    }
    else
    {
        aRxRing[nRxHead] = nByte;
        nRxHead          = nNext;
    }
}

//--------------------------------------------------------------------------------------------------

U16 CtrlLink_Poll(void)
{
    const U32 nBefore = tStats.nFramesOk;

    while (nRxTail != nRxHead)
    {
        const U8 nByte = aRxRing[nRxTail];

        nRxTail = (U16)((nRxTail + 1U) & (CTRL_RX_RING_BYTES - 1U));

        ParseByte(nByte);
    }

    return (U16)(tStats.nFramesOk - nBefore);
}

//--------------------------------------------------------------------------------------------------

STD_RESULT CtrlLink_SendFrame(const U8 eCmd, const U8* const pPayload, const U8 nLength)
{
    STD_RESULT eResult;

    if (nLength > (U8)PROTO_PAYLOAD_MAX)
    {
        eResult = RESULT_INVALID_PARAM_2;
    }
    else if (pfTransmit == NULL_PTR)
    {
        eResult = RESULT_NOT_INIT;
    }
    else
    {
        U16 nCrc;
        U16 nPos = 0U;

        aTxFrame[nPos] = (U8)PROTO_SYNC0; nPos++;
        aTxFrame[nPos] = (U8)PROTO_SYNC1; nPos++;
        aTxFrame[nPos] = nLength;         nPos++;
        aTxFrame[nPos] = eCmd;            nPos++;

        if ((pPayload != NULL_PTR) && (nLength > 0U))
        {
            (void)memcpy(&aTxFrame[nPos], pPayload, (size_t)nLength);
            nPos = (U16)(nPos + nLength);
        }

        // CRC covers LEN, CMD and payload - not the sync word.
        nCrc = Crc16_Ccitt(&aTxFrame[2], (U16)(nLength + 2U), 0xFFFFU);

        aTxFrame[nPos] = (U8)(nCrc & 0xFFU);        nPos++;
        aTxFrame[nPos] = (U8)((nCrc >> 8U) & 0xFFU); nPos++;

        eResult = pfTransmit(aTxFrame, nPos);
    }

    return eResult;
}

//--------------------------------------------------------------------------------------------------

STD_RESULT CtrlLink_SendTelemetry(void)
{
    PROTO_TELEMETRY tTelem;

    AudioSys_GetTelemetry(&tTelem);

    return CtrlLink_SendFrame((U8)PROTO_CMD_TELEMETRY,
                              (const U8*)&tTelem,
                              (U8)sizeof(tTelem));
}

//--------------------------------------------------------------------------------------------------

const CTRL_STATS* CtrlLink_Stats(void)
{
    return &tStats;
}

/****************************************** end of file *******************************************/
