/**
 * @file      ctrl_link.h
 *
 * @details   Framing, parsing and dispatch for the UART control link.
 *
 *            Deliberately HAL-free: transmission goes through a function pointer
 *            supplied at init, and reception is fed one byte at a time. That
 *            makes the entire protocol testable on a PC, which matters because
 *            protocol bugs are the ones that corrupt somebody's signal chain
 *            silently.
 *
 *            WHAT THIS REPLACES
 *
 *            The old link sent 5-byte unframed commands over a circular DMA
 *            buffer, mutated that buffer in place while the DMA was writing to
 *            it, had no CRC, and made the GUI spin on "while (!updateFlag);".
 *            A single dropped byte desynchronised it permanently, and a
 *            desynchronised command is still a VALID command - it would silently
 *            rearrange the signal chain.
 *
 *            Here: sync word, length, CRC-16, resynchronisation on any error,
 *            and nothing blocks on either side.
 *
 * @version   1.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      31.08.2026 - First release
 *
 * @copyright RAT Synthesizers
 */

#ifndef CTRL_LINK_H
#define CTRL_LINK_H



/***************************************************************************************************
* Module includes
***************************************************************************************************/

#include "general.h"
#include "audio_cfg.h"
#include "fx_protocol.h"



/***************************************************************************************************
* Declarations of global (public) data types
***************************************************************************************************/

/**
 * @brief Transmit callback. Must not block; queue and return.
 */
typedef STD_RESULT (*CTRL_TX_FN)(const U8* const pData, const U16 nLength);

/**
 * @brief Link statistics, for diagnostics.
 */
typedef struct stCTRL_STATS
{
    U32 nFramesOk;
    U32 nCrcErrors;
    U32 nResyncs;
    U32 nRxOverflows;

} CTRL_STATS;



/***************************************************************************************************
* Declarations of global (public) functions
***************************************************************************************************/

/** @param pfTx  transmit callback, may be NULL on a receive-only test harness */
extern STD_RESULT CtrlLink_Init(const CTRL_TX_FN pfTx);

/**
 * @brief Push one received byte. Safe to call from an ISR.
 *
 * Bytes go into a lock-free single-producer ring buffer. Nothing is parsed here.
 */
extern void CtrlLink_RxByte(const U8 nByte);

/**
 * @brief Drain the ring, parse complete frames, dispatch them.
 *
 * Call from the SUPER-LOOP only - dispatch calls Grid_Apply, which may clear
 * megabytes of delay line.
 *
 * @return number of frames dispatched
 */
extern U16 CtrlLink_Poll(void);

/** Build and send a telemetry frame. Call from the super-loop. */
extern STD_RESULT CtrlLink_SendTelemetry(void);

/** Send an arbitrary frame. Exposed mainly for tests. */
extern STD_RESULT CtrlLink_SendFrame(const U8 eCmd, const U8* const pPayload, const U8 nLength);

/** Link statistics. Never NULL. */
extern const CTRL_STATS* CtrlLink_Stats(void);



#endif // #ifndef CTRL_LINK_H

/****************************************** end of file *******************************************/
