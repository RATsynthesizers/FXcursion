# AudioController_Claude

A design draft of the FXcursion audio engine in C, sized and shaped for the grid
model in the interface controller. Sits alongside `AudioController_C` for
comparison; nothing here touches the existing projects.

The DSP layer builds and runs on a PC. **80,702 checks, 0 failures, 0 warnings**
with `-Wall -Wextra -Wdouble-promotion -Wfloat-conversion -Wshadow -Wcast-align`.

```bash
cmake -S Test -B Test/build -G Ninja
cmake --build Test/build
./Test/build/fxc_tests
```

---

## The five ideas

**1. There is no allocator, and nothing can be rejected.**

Two constraints from the GUI make dynamic allocation unnecessary: chain widths
always sum to 4, and at most one instance of each effect *type* exists per chain.
Together they mean memory is reserved per `(plane, effect type)` — a static array
in each effect's own `.c` file. No `malloc`, no bump allocator, no fragmentation,
no failure path, and **no arrangement the GUI permits can be refused for want of
memory**, which is what you asked for.

**2. There is no module object.**

An effect "instance" is the pair `(chain, plane)` applied to a row of
`g_aFxEntry[]`. State is indexed by plane, parameters by chain. No vtables, no
per-instance function pointers, nothing to construct, nothing that can dangle.
Adding an effect to a chain changes one byte in a table.

**3. The engine is one loop.**

```c
for (col = 0; col < GRID_SLOT_QTY; col++)
    if (col == mixerCol)  Mixer_Process(...);       /* spans all chains */
    else for (chain ...)  Block_Process(...);
```

Mixer absent, mixer at either edge, empty chains, empty cells — all fall out
with no special cases. There is no "pre-chain" or "post-chain" concept.

**4. Send state, not edits.**

One 96-byte `PROTO_CFG` describes the whole machine. `Grid_Apply` validates it,
clears the state of newly added effects, and publishes a shadow grid with a
single aligned pointer store. That store is the *entire* synchronisation
mechanism between the control path and the audio path — no RTOS, no locks.

**5. Block processing, not per-sample dispatch.**

64 frames per block. This is where the CPU came back: per-sample dispatch over
16 effect-planes costs ~13% of a 480 MHz core in call overhead alone. Now
dispatch is ~0.2% and the budget is **~625 cycles per sample per effect**.

---

## Layout

```
Config/     audio_cfg.h      block size, memory limits, link tuning
            mem_map.h        section placement + compile-time budget proof
Shared/     fx_defs.h/.c     effect pool, parameters, tempo    <- DUPLICATE TO INTERFACE
            fx_protocol.h    wire format                       <- DUPLICATE TO INTERFACE
            fx_crc.h/.c      CRC-16/CCITT                      <- DUPLICATE TO INTERFACE
Modules/    grid.c           topology table, validation, the column loop
            fxblock.c        4 effect slots, trails-on bypass
            params.c         static parameter array, tempo, preset blob
            mixer.c          NxN gain+pan, smoothed, 1/sqrt(N) auto gain
            looper.c         2 lengths, 4 transports, packed 24-bit
            recorder.c       tap -> slot, map derived from topology
            audio_sys.c      block pipeline, meters, telemetry
            Effects/         fx_common (the contract), fx_registry, the effects
Platform/   audio_io.c       SAI binding - the ONLY HAL-aware file
            ctrl_link.c      framing, parsing, dispatch (HAL-free, testable)
            main_example.c   what main() looks like
Test/       CMakeLists.txt   host build
            host/            stand-in for SystemSW/Include
```

Nothing under `Modules/` or `Shared/` includes a HAL header. That is what makes
the host build possible, and it is worth keeping.

---

## Memory budget

Proved at compile time by `FXC_STATIC_ASSERT` in `mem_map.h`.

| | per plane | x4 planes | of |
|---|---|---|---|
| Delay 4 s, FLOAT32, SDRAM bank 1 | 750 KiB | **2.93 MiB** | 16 MiB |
| Loop 15 s, packed 24-bit, bank 2 | 2.06 MiB | **8.24 MiB** | 16 MiB |
| Reverb + modulation lines, AXI SRAM | 53 KiB | **228 KiB** | 320 KiB |
| Scratch, parameters, meters, DTCM | — | **~8 KiB** | 112 KiB |

Two tiers, not one, and the reason is cache rather than capacity: a fully loaded
machine has ~96 short delay-line streams, which in SDRAM would replace the whole
16 KiB D-cache several times per block with zero reuse — roughly a quarter of the
block budget in linefills. Long lines stream at ~1.5 MB/s and belong in SDRAM;
short ones do not.

Headroom: ~13 MiB spare in bank 1 (enough to raise `DELAY_MAX_SEC` to 16),
~7.4 MiB in bank 2 (enough for looper undo at ~12.8 s).

---

## What is real and what is not

**Real:** the grid engine, validation, the protocol, parameters and presets, the
mixer, the looper, the recorder tap, the memory model, and four effects — Amp,
Overdrive, Tremolo (tempo sync worked example) and **Delay** (the hard one:
long line in SDRAM, exact fractional tap, damped feedback, tempo sync).

**Stubs** in `fx_stubs.c`: chorus, flanger, vibrato, reverb, phaser, compressor,
distortion. They are registered, **their memory is really declared** so the
linker map shows the true footprint, and each carries a TODO describing the
algorithm. Each is a self-contained job.

`Platform/audio_io.c` is written against the HAL and is excluded from the host
build, so it is the one file here that has never been compiled.

---

## Before this runs on hardware

1. **Linker script.** `.dtcm` and `.itcm` are `(NOLOAD)` with no input patterns
   in `STM32H743VITX_FLASH.ld`, so objects land there only via ld's
   orphan-merge-by-name rule and get **neither the `.data` copy nor the `.bss`
   zero fill**. Every static here is garbage until `AudioSys_Init()` runs — which
   is exactly why that function exists and initialises everything explicitly. In
   the old C++ project this was hidden by global constructors, and it is the
   single most likely way a C++→C port fails mysteriously.

   `.itcm` needs `AT> FLASH` plus a copy loop in `Reset_Handler` before any code
   is placed there. Add `.sdram_fx` and `.sdram_loop` output sections for the two
   SDRAM banks.

2. **`FPSCR.FZ`** at boot. One line. See `main_example.c`.

3. **MPU.** Keep `RAM_D1_DMA` non-cacheable. Map both SDRAM banks write-through,
   no write-allocate.

4. **SAI.** All four blocks are already synchronous to SAI1 block A in your
   `sai.c`, so **one interrupt drives everything** and SAI2's callbacks stay
   unused. Move to `SAI_PROTOCOL_DATASIZE_24BIT` with word-width DMA.

5. **Build flags.** `-O2` or `-O3` on the DSP files, not `-Os`.
   `-Wdouble-promotion` is not optional.

6. **Interface side.** `Recorder.c` de-interleaves assuming 16-bit samples on an
   8-byte stride. The stream here is `S32` carrying 24 bits, so the stride is
   `REC_SLOT_QTY * 4`. The slot count never changes — only the depth — so this is
   a one-time change. Copy `fx_defs.*`, `fx_protocol.h` and `fx_crc.*` across in
   the same commit and keep them byte-identical.

---

## Deliberate placeholders

Built so that adding them later is not a retrofit:

- **Tempo source.** One `TEMPO` struct with an `eSource` field. Tap and MIDI
  clock both just write BPM into it; the DSP only reads. Adding either touches
  `ctrl_link.c` and nothing else.
- **Loop re-lock.** Each loop stores `fRecordedBpm` and it is written today.
  Re-lock is `fRecordedBpm / current` as a playback ratio. The field is in the
  struct now so loops and presets saved before it ships stay valid after.
- **Presets.** Format fixed and round-trip tested, including CRC rejection of a
  single flipped bit. Nothing writes to SD yet.
- **Tuner.** Should be `FX_TUNER`, a module you place in a chain — so it gets
  budgeted and metered like everything else, rather than an always-on service.
  Telemetry fields exist and read zero.
- **Effect latency.** Taps before and after effects are sample-aligned today
  because everything happens in one block. The moment an effect has lookahead
  that stops being true; `module` needs an `nLatencyFrames` the chain accumulates.

---

## Open questions I made a call on

Flagging these because you may disagree, and they are cheap to change now:

1. **Auto gain is `1/sqrt(N)`, not `1/N`, and it is a switch.** Guitar channels
   are uncorrelated so their sum grows as sqrt(N); `1/N` over-attenuates audibly.
   The old mixer used `1/N` *and* counted connected-but-silent sources. My
   recommendation is still to use it to pick a new connection's DEFAULT gain
   rather than as a permanent live rule — a bus whose level changes because the
   user touched a different bus is baffling. The switch is there to try both.

2. **Loop length may not change while either transport in the pair is running.**
   Length is shared; truncating audio playing on the other chain seemed worse
   than refusing. Say if you would rather it truncated.

3. **Adding an effect does not reset its parameters.** Remove a delay, put it
   back, and it returns with the settings you left on it. `Params_ResetFx` exists
   for an explicit "reset effect".

4. **The output clamps rather than soft-clips**, and counts clips for the meters.
   A soft clip with unity small-signal gain still bends the whole curve.

5. **The recorder stream is fixed width** — always 4 slots, silence in unused
   ones — so the interface never reprograms MDMA when the tap count changes.
