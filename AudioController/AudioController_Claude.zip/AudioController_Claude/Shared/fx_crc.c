/**
 * @file      fx_crc.c
 *
 * @details   CRC-16/CCITT-FALSE implementation.
 *
 *            ############################################################
 *            #  DUPLICATED IN THE INTERFACE CONTROLLER - keep in sync.  #
 *            ############################################################
 *
 * @version   1.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      31.08.2026 - First release
 *
 * @copyright RAT Synthesizers
 */



/***************************************************************************************************
* Module includes
***************************************************************************************************/

#include "fx_crc.h"



/***************************************************************************************************
* Definitions of local (private) constants
***************************************************************************************************/

#define CRC16_POLY                  (0x1021U)



/***************************************************************************************************
* Definitions of global (public) functions
***************************************************************************************************/

U16 Crc16_Ccitt(const U8* const pData, const U16 nLength, const U16 nInit)
{
    U16 nCrc = nInit;
    U16 i;

    if ((pData != NULL_PTR) && (nLength > 0U))
    {
        for (i = 0U; i < nLength; i++)
        {
            U8 nBit;

            nCrc ^= (U16)((U16)pData[i] << 8U);

            for (nBit = 0U; nBit < 8U; nBit++)
            {
                if ((nCrc & 0x8000U) != 0U)
                {
                    nCrc = (U16)(((U16)(nCrc << 1U)) ^ CRC16_POLY);
                }
                else
                {
                    nCrc = (U16)(nCrc << 1U);
                }
            }
        }
    }

    return nCrc;
}

/****************************************** end of file *******************************************/
