/**
 * @file      fx_crc.h
 *
 * @details   CRC-16/CCITT-FALSE, used by the control link and the preset format.
 *
 *            ############################################################
 *            #  DUPLICATED IN THE INTERFACE CONTROLLER - keep in sync.  #
 *            ############################################################
 *
 * @version   1.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      31.08.2026 - First release
 *
 * @copyright RAT Synthesizers
 */

#ifndef FX_CRC_H
#define FX_CRC_H



/***************************************************************************************************
* Module includes
***************************************************************************************************/

#include "general.h"



/***************************************************************************************************
* Declarations of global (public) functions
***************************************************************************************************/

/**
 * @brief CRC-16/CCITT-FALSE. Poly 0x1021, init 0xFFFF, no reflection, no final xor.
 *
 * Bitwise implementation: 8 iterations per byte, no lookup table. A 96-byte
 * configuration frame costs about 3 us on the M7, and this runs in the
 * super-loop, never in the audio ISR. If the control link ever gets fast enough
 * to matter, swap in a 256-entry table - the result must not change.
 *
 * @param pData     buffer, may be NULL only when nLength is 0
 * @param nLength   bytes
 * @param nInit     0xFFFF to start, or the running value to continue
 *
 * @return CRC over the buffer
 */
extern U16 Crc16_Ccitt(const U8* const pData, const U16 nLength, const U16 nInit);



#endif // #ifndef FX_CRC_H

/****************************************** end of file *******************************************/
