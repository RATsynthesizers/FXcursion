/**
 * @file      fx_protocol.h
 *
 * @details   Wire format of the UART control link between the interface
 *            controller and the audio controller.
 *
 *            ############################################################
 *            #  DUPLICATED IN THE INTERFACE CONTROLLER - keep in sync.  #
 *            ############################################################
 *
 *            Design rules, in order of importance:
 *
 *            1. SEND STATE, NOT EDITS. There is no "add effect" or "move effect
 *               up" command. The interface owns the UI model and sends the whole
 *               configuration (PROTO_CFG, 96 bytes) whenever anything about the
 *               grid changes. The audio side rebuilds from it. This removes every
 *               dangling-pointer and half-applied-edit failure mode that an
 *               operation-based protocol has, at a cost of 96 bytes - 8.3 ms at
 *               115200 baud.
 *
 *            2. EVERY FRAME IS FRAMED AND CHECKED. Sync word, length, CRC-16.
 *               A dropped byte must resynchronise, not silently rearrange
 *               somebody's signal chain.
 *
 *            3. NOTHING BLOCKS. The interface must never spin waiting for a
 *               reply. Requests are answered asynchronously.
 *
 *            Frame layout:
 *
 *              +------+------+------+------+---------------+--------+--------+
 *              | 0xA5 | 0x5A | LEN  | CMD  | payload[LEN]  | CRC lo | CRC hi |
 *              +------+------+------+------+---------------+--------+--------+
 *
 *            CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF) over LEN, CMD and
 *            payload. LEN counts payload bytes only.
 *
 * @version   1.0.0
 *
 * @authors   Claude (design draft)
 *
 * \date      31.08.2026 - First release
 *
 * @copyright RAT Synthesizers
 */

#ifndef FX_PROTOCOL_H
#define FX_PROTOCOL_H



/***************************************************************************************************
* Module includes
***************************************************************************************************/

#include "general.h"
#include "fx_defs.h"



/***************************************************************************************************
* Definitions of global (public) constants
***************************************************************************************************/

#define PROTO_SYNC0                     (0xA5U)
#define PROTO_SYNC1                     (0x5AU)

/** Bytes of framing overhead around the payload. */
#define PROTO_OVERHEAD_BYTES            (6U)

/** Largest payload of any command below. */
#define PROTO_PAYLOAD_MAX               (96U)

#define PROTO_FRAME_MAX                 (PROTO_PAYLOAD_MAX + PROTO_OVERHEAD_BYTES)

/**
 * Bumped whenever any struct in this file changes shape OR the effect pool is
 * renumbered. Version 2 split every effect into mono-only and stereo-only types,
 * which renumbered FX_TYPE - so a version-1 interface must not be allowed to
 * talk to a version-2 audio controller.
 */
#define PROTO_VERSION                   (2U)


/* Wire structs below are pinned to an exact size with FXC_STATIC_ASSERT (see
 * fx_defs.h), so that a padding difference between the two firmwares becomes a
 * build error rather than a silently corrupted configuration. */



/***************************************************************************************************
* Declarations of global (public) data types
***************************************************************************************************/

/**
 * @brief Commands. Interface -> audio use 0x00..0x7F, audio -> interface 0x80..0xFF.
 *
 * APPEND ONLY.
 */
typedef enum enPROTO_CMD
{
    /* interface -> audio */
    PROTO_CMD_SET_CONFIG    = 0x01U,    /**< PROTO_CFG        - whole grid state  */
    PROTO_CMD_SET_PARAM     = 0x02U,    /**< PROTO_SET_PARAM  - one parameter     */
    PROTO_CMD_SET_TEMPO     = 0x03U,    /**< PROTO_SET_TEMPO                      */
    PROTO_CMD_TRANSPORT     = 0x04U,    /**< PROTO_TRANSPORT  - looper control    */
    PROTO_CMD_PING          = 0x05U,    /**< no payload                           */

    /* audio -> interface */
    PROTO_CMD_ACK           = 0x81U,    /**< PROTO_ACK                            */
    PROTO_CMD_TELEMETRY     = 0x83U,    /**< PROTO_TELEMETRY                      */
    PROTO_CMD_PONG          = 0x85U     /**< no payload                           */

} PROTO_CMD;

/**
 * @brief Result codes carried by PROTO_ACK.
 */
typedef enum enPROTO_RESULT
{
    PROTO_RES_OK            = 0U,
    PROTO_RES_BAD_VERSION   = 1U,
    PROTO_RES_BAD_TOPOLOGY  = 2U,
    PROTO_RES_BAD_GRID      = 3U,       /**< mixer not a full column, duplicate block, ... */
    PROTO_RES_BAD_PARAM     = 4U,
    PROTO_RES_BUSY          = 5U,       /**< a rebuild is already pending         */
    PROTO_RES_BAD_WIDTH     = 6U        /**< effect width does not match the chain */

} PROTO_RESULT;

/**
 * @brief Looper transport actions.
 *
 * Transport is PER CHAIN. Loop LENGTH is per looper pair (planes 0..1, 2..3).
 */
typedef enum enPROTO_TRANSPORT_ACT
{
    TRANSPORT_STOP          = 0U,
    TRANSPORT_RECORD        = 1U,
    TRANSPORT_OVERDUB       = 2U,
    TRANSPORT_PLAY          = 3U,
    TRANSPORT_CLEAR         = 4U

} PROTO_TRANSPORT_ACT;


/**
 * @brief The whole machine configuration. Payload of PROTO_CMD_SET_CONFIG.
 *
 * Field order is chosen so that every member is naturally aligned and the struct
 * needs no compiler padding on either side. Do not reorder without re-checking
 * the static assertion below.
 *
 * This struct is also the core of the preset format - see params.h.
 */
typedef struct stPROTO_CFG
{
    /* --- 4-byte aligned block ------------------------------------------------------------- */
    U16 aMixGain[CHAIN_MAX_QTY][CHAIN_MAX_QTY];     /**< 0..65535 -> 0.0..2.0 linear   */

    /* --- byte block ---------------------------------------------------------------------- */
    U8  nVersion;                                   /**< PROTO_VERSION                 */
    U8  eTopology;                                  /**< TOPOLOGY                      */
    S8  nMixerCol;                                  /**< column index, or GRID_MIXER_COL_NONE */
    U8  bAutoGain;                                  /**< TRUE: apply 1/sqrt(N) bus gain */

    U8  aSlot[CHAIN_MAX_QTY][GRID_SLOT_QTY];        /**< BLOCK_TYPE per grid cell      */
    U8  aFxSlot[CHAIN_MAX_QTY][FXBLOCK_SLOT_QTY];   /**< FX_TYPE, or FX_TYPE_NONE      */
    U8  aFxEnabled[CHAIN_MAX_QTY];                  /**< bitmask over FX slots         */
    S8  aMixPan[CHAIN_MAX_QTY][CHAIN_MAX_QTY];      /**< -128..127 -> -1.0..+1.0       */
    U8  aLoopBars[LOOPER_QTY];                      /**< loop length in bars, per pair */
    U8  nBeatsPerBar;                               /**< time signature numerator      */
    U8  nBeatUnit;                                  /**< time signature denominator    */

    /* --- 2-byte aligned tail -------------------------------------------------------------- */
    U16 nBpmX10;                                    /**< tempo * 10, e.g. 1200 = 120.0 */
    U8  nReserved[2];

} PROTO_CFG;

FXC_STATIC_ASSERT(sizeof(PROTO_CFG) == 96U, proto_cfg_size);


/**
 * @brief Payload of PROTO_CMD_SET_PARAM.
 *
 * Parameters are addressed by (chain, effect type, index) - never by grid
 * position. Because at most one instance of each effect type exists per chain,
 * that address is unique and computable, so reordering effects inside an FX
 * block does not disturb their settings.
 */
typedef struct stPROTO_SET_PARAM
{
    U16 nValue;                 /**< 0..65535 -> 0.0..1.0 normalised             */
    U8  nChain;                 /**< 0..CHAIN_MAX_QTY-1                          */
    U8  eFxType;                /**< FX_TYPE                                     */
    U8  nParamIdx;              /**< 0..FX_PARAM_QTY-1                           */
    U8  bSync;                  /**< TRUE: derive value from tempo               */
    U8  eDivision;              /**< NOTE_DIV, used when bSync is TRUE           */
    U8  nReserved;

} PROTO_SET_PARAM;

FXC_STATIC_ASSERT(sizeof(PROTO_SET_PARAM) == 8U, proto_set_param_size);


/**
 * @brief Payload of PROTO_CMD_SET_TEMPO.
 */
typedef struct stPROTO_SET_TEMPO
{
    U16 nBpmX10;
    U8  nBeatsPerBar;
    U8  nBeatUnit;

} PROTO_SET_TEMPO;

FXC_STATIC_ASSERT(sizeof(PROTO_SET_TEMPO) == 4U, proto_set_tempo_size);


/**
 * @brief Payload of PROTO_CMD_TRANSPORT.
 */
typedef struct stPROTO_TRANSPORT
{
    U8 nChain;
    U8 eAction;                 /**< PROTO_TRANSPORT_ACT                         */
    U8 nReserved[2];

} PROTO_TRANSPORT;

FXC_STATIC_ASSERT(sizeof(PROTO_TRANSPORT) == 4U, proto_transport_size);


/**
 * @brief Payload of PROTO_CMD_ACK.
 *
 * aRecSlot is the recorder slot map the audio side actually committed to.
 *
 * The interface MUST reconfigure its SPI de-interleave descriptor to match this
 * map before it trusts the recorded stream. Sequence:
 *      interface: SET_CONFIG  ->  audio: validate, ACK with slot map
 *      interface: reprogram MDMA  ->  audio: stream in the new format
 * Without this handshake there is a window in which recorded channels are
 * silently rotated on the SD card.
 */
typedef struct stPROTO_ACK
{
    U8 eResult;                             /**< PROTO_RESULT                    */
    U8 eEchoCmd;                            /**< command being acknowledged      */
    U8 nRecSlotQty;                         /**< slots in use, 0..REC_SLOT_QTY   */
    U8 nStreamWidth;                        /**< interleave stride, in samples   */
    U8 aRecSlot[CHAIN_MAX_QTY];             /**< first slot per chain, or REC_SLOT_NONE */

} PROTO_ACK;

FXC_STATIC_ASSERT(sizeof(PROTO_ACK) == 8U, proto_ack_size);


/**
 * @brief Payload of PROTO_CMD_TELEMETRY. Sent every TELEMETRY_PERIOD_MS.
 *
 * Everything the GUI header bar and meters need. Written by the audio ISR, read
 * by the super-loop; a torn read of a meter is harmless, and nSeq lets the
 * interface detect a torn frame if it ever cares.
 */
typedef struct stPROTO_TELEMETRY
{
    U32 aLoopPos[LOOPER_QTY];               /**< playhead, frames                */
    U32 aLoopLen[LOOPER_QTY];               /**< loop length, frames, 0 = empty  */

    U16 nSeq;
    U16 nCpuPermille;                       /**< 0..1000, last block             */
    U16 nCpuPeakPermille;                   /**< 0..1000, worst since boot       */
    U16 nOverruns;                          /**< blocks that missed the deadline */

    U16 aPeak[AUDIO_PLANE_QTY];             /**< 0..65535 -> 0.0..1.0            */
    U16 aRms[AUDIO_PLANE_QTY];

    U16 nTunerHzX10;                        /**< detected pitch * 10, 0 = none   */
    U8  nTunerConfidence;                   /**< 0..255                          */
    U8  nVersion;                           /**< PROTO_VERSION                   */

    U8  aTransport[CHAIN_MAX_QTY];          /**< PROTO_TRANSPORT_ACT per chain   */

} PROTO_TELEMETRY;

FXC_STATIC_ASSERT(sizeof(PROTO_TELEMETRY) == 48U, proto_telemetry_size);


FXC_STATIC_ASSERT(sizeof(PROTO_CFG) <= PROTO_PAYLOAD_MAX, proto_payload_fits);



#endif // #ifndef FX_PROTOCOL_H

/****************************************** end of file *******************************************/
